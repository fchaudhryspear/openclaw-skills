import base64
import json
import logging
import os
import re
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, Optional

import bleach
import pandas as pd
import snowflake.connector
from aws_lambda_powertools.logging import Logger, formatter
from cryptography.hazmat.primitives import serialization
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    condecimal,
    constr,
    root_validator,
    validator,
)
from snowflake.connector.pandas_tools import write_pandas

# ... (rest of the imports)

# Initialize structured logger
logger = Logger(service="application-webhook")


# -start-of-changes-
# Configure structured logging for security events
def setup_security_logger():
    """Sets up a logger for security events in JSON format."""
    security_logger = logging.getLogger("security")
    if not security_logger.handlers:
        handler = logging.StreamHandler()
        # Use a JSON formatter
        json_formatter = formatter.JsonFormatter(
            json_fields={
                "timestamp": "asctime",
                "level": "levelname",
                "event_type": "event_type",
                "details": "message",
            }
        )
        handler.setFormatter(json_formatter)
        security_logger.addHandler(handler)
    security_logger.setLevel(logging.INFO)
    return security_logger


security_logger = setup_security_logger()


def log_security_event(event_type: str, details: Dict[str, Any]):
    """Logs a security event with a specific type and details."""
    security_logger.info(details, extra={"event_type": event_type})
    # -end-of-changes-

    @root_validator(pre=True)
    def sanitize_fields(cls, values):
        sanitized_values = {}
        for k, v in values.items():
            if isinstance(v, str):
                sanitized_values[k] = bleach.clean(v).strip()
            else:
                sanitized_values[k] = v
        return sanitized_values


class LoanApplication(BaseModel):
    model_config = ConfigDict(extra="forbid")

    application_id: str = Field(pattern=r"^app-\d{3}$")
    customer_name: str
    loan_amount: Decimal = Field(decimal_places=2, ge=0, le=10000000)
    loan_purpose: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    account_number: Optional[str] = None

    @root_validator(pre=True)
    def sanitize_fields(cls, values):
        sanitized_values = {}
        for k, v in values.items():
            if isinstance(v, str):
                sanitized_values[k] = bleach.clean(v).strip()
            else:
                sanitized_values[k] = v
        return sanitized_values


class ApplicationResponse(BaseModel):
    """Standard API Response Model"""

    status: str
    application_id: str
    message: str
    timestamp: str


def _convert_key_to_der(private_key_raw: str) -> bytes:
    """
    Convert private key from various formats to DER bytes for Snowflake.
    Handles:
    - Base64-encoded DER (recommended for env vars)
    - PEM format (with or without headers)
    """
    private_key_raw = private_key_raw.strip()
    # Check if it's PEM format (contains BEGIN/END)
    if "BEGIN" in private_key_raw and "END" in private_key_raw:
        # It's PEM - convert to DER
        private_key = serialization.load_pem_private_key(
            private_key_raw.encode("utf-8"),
            password=None,
        )
        return private_key.private_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
    # Assume it's base64-encoded DER (no newlines, no headers)
    try:
        return base64.b64decode(private_key_raw)
    except Exception:
        raise ValueError(
            "Private key format not recognized. "
            "Expected PEM format or base64-encoded DER."
        )


def get_snowflake_connection(request_id: str):
    """
    Establish secure Snowflake connection using key pair authentication.
    Supports two key formats:
    1. Base64-encoded DER (stored in env var/Secrets Manager as string)
    2. PEM format (with -----BEGIN PRIVATE KEY----- headers)
    """
    logger.info("Attempting to connect to Snowflake", extra={"request_id": request_id})
    try:
        # Get the private key from environment
        private_key_raw = os.environ.get("SNOWFLAKE_PRIVATE_KEY")
        if not private_key_raw:
            raise ValueError("SNOWFLAKE_PRIVATE_KEY environment variable not set")
        # Convert to DER bytes for Snowflake
        private_key_der = _convert_key_to_der(private_key_raw)
        conn = snowflake.connector.connect(
            account=os.environ["SNOWFLAKE_ACCOUNT"],
            user=os.environ["SNOWFLAKE_USER"],
            warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
            database=os.environ["SNOWFLAKE_DATABASE"],
            schema=os.environ["SNOWFLAKE_SCHEMA"],
            private_key=private_key_der,  # Must be DER bytes, not string
            client_session_keep_alive=True,
        )
        logger.info("Successfully connected to Snowflake", extra={"request_id": request_id})
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to Snowflake: {str(e)}", extra={"request_id": request_id})
        raise


def insert_application_to_snowflake(
    app_data: LoanApplication, request_id: str, source_ip: str
) -> bool:
    """Insert validated application into Snowflake staging table"""
    conn = None
    try:
        conn = get_snowflake_connection(request_id)

        # Convert to DataFrame for bulk insert
        df = pd.DataFrame(
            [
                {
                    "APPLICATION_ID": app_data.application_id,
                    "APPLICANT_NAME": app_data.customer_name,
                    "LOAN_AMOUNT": app_data.loan_amount,
                    "LOAN_PURPOSE": app_data.loan_purpose,
                    "EMAIL": app_data.email,
                    "PHONE": app_data.phone,
                    "ADDRESS": app_data.address,
                    "ACCOUNT_NUMBER": app_data.account_number,
                    "INGESTION_TIMESTAMP": datetime.utcnow(),
                    "SOURCE_SYSTEM": "CRM_WEBHOOK",
                    "VALIDATION_STATUS": "PASSED",
                }
            ]
        )

        # Write to staging table
        success, num_chunks, num_rows, output = write_pandas(
            conn=conn,
            df=df,
            table_name="APPLICATIONS_STAGING",
            database=os.environ["SNOWFLAKE_DATABASE"],
            schema=os.environ["SNOWFLAKE_SCHEMA"],
        )

        # Log data operation for audit trail
        log_security_event(
            "DATA_OPERATION",
            {
                "operation": "INSERT",
                "table": "APPLICATIONS_STAGING",
                "application_id": app_data.application_id,
                "rows_affected": num_rows,
                "request_id": request_id,
                "source_ip": source_ip,
            },
        )

        logger.info(
            f"Successfully inserted application {app_data.application_id}",
            extra={
                "application_id": app_data.application_id,
                "rows_inserted": num_rows,
                "request_id": request_id,
            },
        )

        return success

    except Exception as e:
        # Log data operation failure
        log_security_event(
            "DATA_OPERATION_FAILURE",
            {
                "operation": "INSERT",
                "table": "APPLICATIONS_STAGING",
                "application_id": app_data.application_id,
                "error": str(e),
                "request_id": request_id,
                "source_ip": source_ip,
            },
        )
        logger.error(
            f"Failed to insert application: {str(e)}",
            extra={"application_id": app_data.application_id, "request_id": request_id},
        )
        raise
    finally:
        if conn:
            conn.close()
            logger.info("Snowflake connection closed", extra={"request_id": request_id})


def create_success_response(app_id: str) -> Dict[str, Any]:
    """Create standardized success response"""
    response = ApplicationResponse(
        status="success",
        application_id=app_id,
        message="Application received and validated successfully",
        timestamp=datetime.utcnow().isoformat(),
    )
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json", "X-Request-ID": app_id},
        "body": json.dumps(response.dict()),
    }


def create_error_response(status_code: int, message: str, request_id: str = None) -> Dict[str, Any]:
    """Create standardized error response (security-hardened)"""
    # Log detailed error internally
    logger.error(
        f"Request failed: {message}", extra={"status_code": status_code, "request_id": request_id}
    )

    # Return generic message to client (don't expose internal details)
    error_messages = {
        400: "Invalid request - please check your input data",
        401: "Authentication required",
        403: "Access denied",
        500: "Internal server error - please try again later",
    }

    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(
            {
                "status": "error",
                "message": error_messages.get(status_code, "An error occurred"),
                "request_id": request_id,
                "timestamp": datetime.utcnow().isoformat(),
            }
        ),
    }


@logger.inject_lambda_context(correlation_id_path="headers.X-Request-ID")
def lambda_handler(event, context):
    """
    Application Webhook Handler - Production Ready

    Features:
    - Input validation with Pydantic
    - Snowflake integration
    - Structured logging
    - Security-hardened error handling
    - Audit trail
    """
    request_id = context.aws_request_id if context else str(datetime.utcnow().timestamp())
    source_ip = event.get("requestContext", {}).get("identity", {}).get("sourceIp")

    try:
        # Log incoming request (sanitized)
        logger.info(
            "Received application webhook",
            extra={"source_ip": source_ip, "http_method": event.get("httpMethod")},
        )

        # Parse request body
        body = json.loads(event.get("body", "{}"))

        # Validate input with Pydantic
        try:
            application = LoanApplication(**body)
            log_security_event(
                "VALIDATION_SUCCESS",
                {"request_id": request_id, "application_id": body.get("application_id")},
            )
        except ValidationError as e:
            validation_errors = []
            for error in e.errors():
                validation_errors.append(
                    {"field": " -> ".join(str(x) for x in error["loc"]), "message": error["msg"]}
                )

            log_security_event(
                "VALIDATION_FAILURE", {"request_id": request_id, "errors": validation_errors}
            )

            logger.warning("Validation failed", extra={"errors": validation_errors})

            return create_error_response(400, f"Validation failed: {validation_errors}", request_id)

        # Insert into Snowflake
        insert_application_to_snowflake(application, request_id, source_ip)

        # Log success
        logger.info(
            "Application processed successfully",
            extra={
                "application_id": application.application_id,
                "loan_amount": application.loan_amount,
            },
        )

        return create_success_response(application.application_id)

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in request body: {str(e)}")
        return create_error_response(400, "Invalid JSON format", request_id)

    except Exception as e:
        logger.exception(f"Unexpected error processing application: {str(e)}")
        return create_error_response(500, "Internal processing error", request_id)
