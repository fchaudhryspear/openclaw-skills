#!/usr/bin/env python3
"""
LLM Topic Classifier Module for Model Orchestrator v2.0

Fallback classifier using LLM when keyword matching is insufficient.
Handles ambiguous, complex, or unseen topics gracefully.
Part of NexDev AI Coding Stack - Phase 4 Implementation
"""

import json
import re
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

# Configuration
CONFIG_PATH = Path.home() / ".openclaw/workspace/memory/routing_topics.json"


@dataclass
class ClassificationResult:
    """Represents an LLM classification result."""
    topic: str
    confidence: float
    method: str  # "keyword" or "llm"
    reasoning: str


def load_predefined_topics() -> List[str]:
    """Load list of predefined topics from config."""
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        return list(config.get("topics", {}).keys())
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def should_use_llm_classifier(query: str, keyword_matches: List[Dict]) -> bool:
    """
    Decide whether to use LLM classification based on keyword results.

    Args:
        query: User's query text
        keyword_matches: Results from keyword-based extraction

    Returns:
        True if LLM classification should be used
    """
    # Use LLM if no keyword matches found
    if not keyword_matches:
        return True

    # Use LLM if top match has low confidence (< 0.5)
    top_match = max(keyword_matches, key=lambda x: x.get('confidence', 0))
    if top_match.get('confidence', 0) < 0.5:
        return True

    # Use LLM if multiple equally strong matches (ambiguous)
    max_confidence = top_match.get('confidence', 0)
    strong_matches = [m for m in keyword_matches if m.get('confidence', 0) >= max_confidence * 0.9]
    if len(strong_matches) > 2:
        return True

    # Otherwise stick with keyword matching
    return False


def classify_with_llm(query: str, available_topics: List[str]) -> Optional[ClassificationResult]:
    """
    Use LLM to classify query into predefined topics.

    Args:
        query: User's query text
        available_topics: List of valid topic names to choose from

    Returns:
        ClassificationResult or None if classification fails
    """
    # Build prompt for lightweight classification
    topic_list = "\n".join([f"  - {topic}" for topic in available_topics])

    prompt = f"""You are a topic classifier. Classify this query into ONE of these predefined topics:

{topic_list}

Query: "{query}"

Return ONLY a JSON object with this exact format:
{{
  "topic": "<topic_name>",
  "confidence": <0.0-1.0>,
  "reasoning": "<brief explanation>"
}}

If none of the topics fit, return:
{{
  "topic": "general",
  "confidence": 0.5,
  "reasoning": "No specific technical topic identified"
}}
"""

    # This would call an actual LLM in production
    # For now, we simulate with heuristic-based fallback
    
    # Simulated LLM response based on query patterns
    simulated_response = _simulate_llm_classification(query, available_topics)
    
    try:
        result = json.loads(simulated_response)
        return ClassificationResult(
            topic=result.get("topic", "general"),
            confidence=min(1.0, max(0.0, float(result.get("confidence", 0.5)))),
            method="llm",
            reasoning=result.get("reasoning", "LLM classification")
        )
    except (json.JSONDecodeError, ValueError):
        return None


def _simulate_llm_classification(query: str, available_topics: List[str]) -> str:
    """
    Simulate LLM classification using pattern matching.
    
    In production, replace this with actual LLM API call.
    """
    query_lower = query.lower()
    
    # Simple heuristics to simulate LLM understanding
    topic_scores = {}
    
    # AWS-related queries
    if any(kw in query_lower for kw in ["lambda", "aws", "cloudwatch", "s3", "ec2", "iam"]):
        if "lambda-development" in available_topics:
            topic_scores["lambda-development"] = 0.85
        if "api-gateway-cors" in available_topics and ("cors" in query_lower or "gateway" in query_lower):
            topic_scores["api-gateway-cors"] = 0.90
        if "infrastructure-as-code" in available_topics:
            topic_scores["infrastructure-as-code"] = 0.70
    
    # Testing-related queries
    if any(kw in query_lower for kw in ["test", "pytest", "jest", "unit test", "integration test"]):
        if "testing-setup" in available_topics:
            topic_scores["testing-setup"] = 0.92
    
    # Security queries
    if any(kw in query_lower for kw in ["security", "vulnerability", "owasp", "injection", "auth bypass"]):
        if "security-audit-code" in available_topics:
            topic_scores["security-audit-code"] = 0.95
    
    # Database queries
    if any(kw in query_lower for kw in ["database", "sql", "schema", "migration", "snowflake"]):
        if "database-migrations" in available_topics and any(kw in query_lower for kw in ["migration", "schema", "change"]):
            topic_scores["database-migrations"] = 0.88
        if "snowflake-integration" in available_topics and "snowflake" in query_lower:
            topic_scores["snowflake-integration"] = 0.90
    
    # Web/frontend queries
    if any(kw in query_lower for kw in ["react", "vue", "angular", "css", "html", "frontend"]):
        if "web-development" in available_topics:
            topic_scores["web-development"] = 0.85
    
    # Backend framework queries
    if any(kw in query_lower for kw in ["fastapi", "express", "django", "flask", "spring", "rails"]):
        if "backend-framework" in available_topics:
            topic_scores["backend-framework"] = 0.87
    
    # Architecture queries
    if any(kw in query_lower for kw in ["architecture", "microservice", "scalable", "design pattern"]):
        if "system-architecture" in available_topics:
            topic_scores["system-architecture"] = 0.90
    
    # Debugging queries
    if any(kw in query_lower for kw in ["debug", "error", "exception", "stack trace", "bug"]):
        if "debugging-troubleshooting" in available_topics:
            topic_scores["debugging-troubleshooting"] = 0.85
    
    # Find best matching topic
    if topic_scores:
        best_topic = max(topic_scores.items(), key=lambda x: x[1])
        return json.dumps({
            "topic": best_topic[0],
            "confidence": best_topic[1],
            "reasoning": f"Detected keywords suggest {best_topic[0]}"
        })
    
    # No specific topic found
    return json.dumps({
        "topic": "general",
        "confidence": 0.5,
        "reasoning": "Query does not match any specific technical topic"
    })


def auto_classify_topic(query: str) -> Dict[str, Any]:
    """
    Smart hybrid classification: keywords first, LLM fallback.

    Args:
        query: User's query text

    Returns:
        Dictionary with classification result
    """
    from topic_extractor import extract_topic
    
    # Step 1: Try keyword matching
    keyword_results = extract_topic(query)
    
    # Convert to dict format for decision logic
    keyword_matches = [
        {"topic": r.topic, "confidence": r.confidence}
        for r in keyword_results
    ]
    
    # Step 2: Decide if LLM needed
    if not should_use_llm_classifier(query, keyword_matches):
        # Use best keyword match
        if keyword_matches:
            best = max(keyword_matches, key=lambda x: x["confidence"])
            return {
                "topic": best["topic"],
                "confidence": best["confidence"],
                "method": "keyword"
            }
    
    # Step 3: Fallback to LLM classification
    available_topics = load_predefined_topics()
    llm_result = classify_with_llm(query, available_topics)
    
    if llm_result:
        return {
            "topic": llm_result.topic,
            "confidence": llm_result.confidence,
            "method": "llm-classification"
        }
    
    # Ultimate fallback
    return {
        "topic": "general",
        "confidence": 0.5,
        "method": "fallback"
    }


def add_custom_topic(topic_name: str, description: str, example_queries: List[str]) -> bool:
    """
    Add a custom topic that will be recognized by LLM classifier.

    Args:
        topic_name: Name of the new topic
        description: Detailed description for LLM context
        example_queries: Sample queries that should match this topic

    Returns:
        True if successful
    """
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        
        config["topics"][topic_name] = {
            "description": description,
            "example_queries": example_queries,
            "keywords": [],  # Will rely on LLM classification
            "tier": "medium",
            "preferred_models": ["alibaba-sg/qwen3.5-122b-a10b"],
            "fallback_model": "google/gemini-2.5-flash"
        }
        
        with open(CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=2)
        
        return True
        
    except Exception as e:
        print(f"Error adding custom topic: {e}")
        return False


def debug_classification(query: str) -> Dict[str, Any]:
    """
    Debug helper to see classification process.

    Args:
        query: User's query text

    Returns:
        Dictionary with detailed classification info
    """
    from topic_extractor import extract_topic
    
    result = {
        "query": query,
        "keyword_results": [],
        "llm_used": False,
        "final_classification": None
    }
    
    # Get keyword results
    keyword_results = extract_topic(query)
    result["keyword_results"] = [
        {"topic": r.topic, "confidence": r.confidence, "matched_keywords": r.matched_keywords}
        for r in keyword_results
    ]
    
    # Determine if LLM would be used
    keyword_matches = [{"topic": r.topic, "confidence": r.confidence} for r in keyword_results]
    result["llm_used"] = should_use_llm_classifier(query, keyword_matches)
    
    # Perform final classification
    final = auto_classify_topic(query)
    result["final_classification"] = final
    
    return result


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("TOPIC CLASSIFIER - Self Test")
    print("=" * 60)

    test_queries = [
        "Fix Lambda timeout causing 504 errors",
        "Design scalable event-driven microservice architecture",
        "How do I center a div vertically?",
        "What time is it in Paris?",  # Should fallback to general
    ]

    print("\n🧪 Testing classification:\n")

    for query in test_queries:
        print(f"Query: {query}")
        
        # Debug mode
        result = debug_classification(query)
        
        print(f"  Keyword matches: {len(result['keyword_results'])}")
        for kr in result['keyword_results'][:2]:
            print(f"    - {kr['topic']} (conf: {kr['confidence']:.2f})")
        
        print(f"  LLM fallback used: {result['llm_used']}")
        
        final = result['final_classification']
        print(f"  Final: {final['topic']} ({final['method']}, conf: {final['confidence']:.2f})")
        print()

    print("=" * 60)
    print("Test complete!")
