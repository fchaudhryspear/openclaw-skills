#!/usr/bin/env python3
"""
Database Initialization Script for Model Orchestrator v2.0

Creates SQLite database schema for project memory graph and MO tracking.
Part of NexDev AI Coding Stack - Phase 1 Implementation
"""

import sqlite3
from pathlib import Path
from datetime import datetime

# Paths
WORKSPACE = Path.home() / ".openclaw/workspace"
MEMORY_DIR = WORKSPACE / "memory"
DB_PATH = MEMORY_DIR / "project_graph.db"


def ensure_directories():
    """Ensure all required directories exist."""
    directories = [
        MEMORY_DIR,
        Path.home() / ".openclaw/bin"
    ]

    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
        print(f"✅ Directory ready: {directory}")


def create_database_schema():
    """Create or update database schema."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Projects table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            repo_url TEXT,
            language TEXT,
            framework TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Tasks table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            project_id TEXT REFERENCES projects(id),
            title TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'pending',
            agent TEXT,
            model_used TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id)
        )
    ''')

    # Performance logs table (for MO learning)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS performance_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            topic TEXT NOT NULL,
            model_used TEXT NOT NULL,
            success BOOLEAN,
            tokens_input INTEGER,
            tokens_output INTEGER,
            cost_usd REAL,
            confidence_score REAL,
            query_text TEXT,
            response_summary TEXT
        )
    ''')

    # Create index on performance_logs for faster queries
    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_performance_topic
        ON performance_logs(topic)
    ''')

    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_performance_model
        ON performance_logs(model_used)
    ''')

    cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_performance_timestamp
        ON performance_logs(timestamp)
    ''')

    # Daily costs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS daily_costs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date DATE UNIQUE,
            total_cost_usd REAL DEFAULT 0,
            query_count INTEGER DEFAULT 0,
            by_model TEXT,
            by_topic TEXT
        )
    ''')

    # Session state table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS session_state (
            id INTEGER PRIMARY KEY,
            current_topic TEXT,
            current_model TEXT,
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Insert default session state if not exists
    cursor.execute('SELECT COUNT(*) FROM session_state')
    if cursor.fetchone()[0] == 0:
        cursor.execute(
            'INSERT INTO session_state (current_topic, current_model, started_at) VALUES (?, ?, ?)',
            ("general", "google/gemini-2.0-flash-lite", datetime.now().isoformat())
        )

    # Feedback table (for Phase 5 RL feedback)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            query_id TEXT,
            topic TEXT,
            model_used TEXT,
            rating INTEGER CHECK(rating >= 1 AND rating <= 5),
            comments TEXT
        )
    ''')

    # Topic embeddings table (for Phase 5 semantic search)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS topic_embeddings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic_name TEXT UNIQUE,
            description TEXT,
            embedding_vector BLOB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.commit()
    conn.close()

    print(f"\n✅ Database created at {DB_PATH}")
    print("\nTables created:")
    print("  - projects              (Project registry)")
    print("  - tasks                 (Active/completed tasks)")
    print("  - performance_logs      (MO learning data)")
    print("  - daily_costs           (Cost tracking)")
    print("  - session_state         (Sticky topics)")
    print("  - user_feedback         (RL feedback)")
    print("  - topic_embeddings      (Semantic vectors)")


def initialize_config_files():
    """Initialize configuration files if they don't exist."""
    from pathlib import Path
    import json

    # Model pricing config
    pricing_path = Path.home() / ".openclaw/workspace/memory/model_pricing.json"
    if not pricing_path.exists():
        pricing_config = {
            "version": "1.0",
            "updated": datetime.now().strftime("%Y-%m-%d"),
            "models": {
                "google/gemini-2.0-flash-lite": {
                    "input_cost_per_million_tokens": 0.10,
                    "output_cost_per_million_tokens": 0.40,
                    "context_window": 1000000,
                    "tier": "ultra-cheap",
                    "use_cases": ["simple_qa", "extraction", "summaries"]
                },
                "google/gemini-2.5-flash": {
                    "input_cost_per_million_tokens": 0.10,
                    "output_cost_per_million_tokens": 0.40,
                    "context_window": 1000000,
                    "tier": "cheap",
                    "use_cases": ["code_review", "long_docs", "vision"]
                },
                "alibaba-sg/qwen-turbo": {
                    "input_cost_per_million_tokens": 0.05,
                    "output_cost_per_million_tokens": 0.20,
                    "context_window": 256000,
                    "tier": "ultra-cheap",
                    "use_cases": ["quick_facts", "simple_extraction"]
                },
                "alibaba-sg/qwen-coder": {
                    "input_cost_per_million_tokens": 0.30,
                    "output_cost_per_million_tokens": 0.60,
                    "context_window": 256000,
                    "tier": "cheap",
                    "use_cases": ["code_generation", "debugging", "refactoring"]
                },
                "alibaba-sg/qwen3.5-122b-a10b": {
                    "input_cost_per_million_tokens": 0.40,
                    "output_cost_per_million_tokens": 1.20,
                    "context_window": 256000,
                    "tier": "medium",
                    "use_cases": ["complex_coding", "architecture", "system_design"]
                },
                "anthropic/claude-sonnet-4-6": {
                    "input_cost_per_million_tokens": 3.00,
                    "output_cost_per_million_tokens": 15.00,
                    "context_window": 200000,
                    "tier": "expert",
                    "use_cases": ["security_review", "critical_decisions", "code_ownership"]
                },
                "anthropic/claude-opus-4-6": {
                    "input_cost_per_million_tokens": 15.00,
                    "output_cost_per_million_tokens": 75.00,
                    "context_window": 200000,
                    "tier": "nuclear",
                    "use_cases": ["hardest_problems", "final_approval"]
                }
            },
            "budget_limits": {
                "daily_max_usd": 20.00,
                "per_query_max_usd": 5.00,
                "monthly_project_limit_usd": 300.00
            }
        }

        with open(pricing_path, 'w') as f:
            json.dump(pricing_config, f, indent=2)

        print(f"\n✅ Created {pricing_path.name}")

    # Routing topics config
    routing_path = Path.home() / ".openclaw/workspace/memory/routing_topics.json"
    if not routing_path.exists():
        routing_config = {
            "version": "1.0",
            "topics": {
                "lambda-development": {
                    "keywords": ["lambda", "aws lambda", "lambda function", "serverless function"],
                    "tier": "medium",
                    "preferred_models": ["alibaba-sg/qwen3.5-122b-a10b", "anthropic/claude-sonnet-4-6"],
                    "fallback_model": "google/gemini-2.5-flash"
                },
                "api-gateway-cors": {
                    "keywords": ["cors", "api gateway", "cross-origin", "504 error", "502 error"],
                    "tier": "medium",
                    "preferred_models": ["alibaba-sg/qwen3.5-122b-a10b", "google/gemini-2.5-flash"],
                    "fallback_model": "google/gemini-2.0-flash-lite"
                },
                "testing-setup": {
                    "keywords": ["test", "pytest", "jest", "unit test", "integration test"],
                    "tier": "cheap",
                    "preferred_models": ["alibaba-sg/qwen-coder", "google/gemini-2.5-flash"],
                    "fallback_model": "google/gemini-2.0-flash-lite"
                },
                "web-development": {
                    "keywords": ["react", "vue", "angular", "frontend", "css", "html"],
                    "tier": "cheap",
                    "preferred_models": ["google/gemini-2.5-flash", "alibaba-sg/qwen-coder"],
                    "fallback_model": "google/gemini-2.0-flash-lite"
                },
                "security-audit-code": {
                    "keywords": ["security", "vulnerability", "owasp", "injection"],
                    "tier": "expert",
                    "preferred_models": ["anthropic/claude-sonnet-4-6", "anthropic/claude-opus-4-6"],
                    "fallback_model": "alibaba-sg/qwen3.5-122b-a10b",
                    "requires_human_review": True
                },
                "database-migrations": {
                    "keywords": ["migration", "schema change", "alembic", "liquibase"],
                    "tier": "expert",
                    "preferred_models": ["anthropic/claude-sonnet-4-6", "alibaba-sg/qwen3.5-122b-a10b"],
                    "fallback_model": "alibaba-sg/qwen-plus"
                },
                "debugging-troubleshooting": {
                    "keywords": ["debug", "error", "stack trace", "exception", "bug", "fix"],
                    "tier": "medium",
                    "preferred_models": ["alibaba-sg/qwen3.5-122b-a10b", "anthropic/claude-sonnet-4-6"],
                    "fallback_model": "google/gemini-2.5-flash"
                },
                "system-architecture": {
                    "keywords": ["architecture", "design pattern", "microservice", "scalability"],
                    "tier": "expert",
                    "preferred_models": ["anthropic/claude-sonnet-4-6", "alibaba-sg/qwen3.5-122b-a10b"],
                    "fallback_model": "anthropic/claude-opus-4-6"
                },
                "code-refactoring": {
                    "keywords": ["refactor", "optimize", "improve", "technical debt"],
                    "tier": "medium",
                    "preferred_models": ["alibaba-sg/qwen3.5-122b-a10b", "alibaba-sg/qwen-coder"],
                    "fallback_model": "google/gemini-2.5-flash"
                },
                "infrastructure-as-code": {
                    "keywords": ["terraform", "cloudformation", "pulumi", "cdk"],
                    "tier": "medium",
                    "preferred_models": ["alibaba-sg/qwen3.5-122b-a10b", "xai/grok-4-1-fast"],
                    "fallback_model": "google/gemini-2.5-flash"
                }
            },
            "default_topic": "general",
            "unknown_topic_fallback": "google/gemini-2.0-flash-lite"
        }

        with open(routing_path, 'w') as f:
            json.dump(routing_config, f, indent=2)

        print(f"✅ Created {routing_path.name}")

    # MO config file
    mo_config_path = Path.home() / ".openclaw/workspace/memory/.mo_config.json"
    if not mo_config_path.exists():
        mo_config = {
            "version": "2.0",
            "strategy": "balanced",
            "weights": {
                "cost": 0.33,
                "speed": 0.33,
                "quality": 0.34
            },
            "auto_logging": True,
            "confidence_threshold": 0.75,
            "min_usage_for_learning": 3
        }

        with open(mo_config_path, 'w') as f:
            json.dump(mo_config, f, indent=2)

        print(f"✅ Created {mo_config_path.name}")


def create_cli_wrapper():
    """Create mo-stats CLI wrapper script."""
    cli_path = Path.home() / ".openclaw/bin/mo-stats"

    cli_script = '''#!/usr/bin/env python3
"""MO Stats CLI Wrapper"""

import sys
from pathlib import Path

# Add memory directory to path
sys.path.insert(0, str(Path.home() / ".openclaw/workspace/memory"))

from mo_dashboard import main

if __name__ == "__main__":
    main()
'''

    cli_path.parent.mkdir(parents=True, exist_ok=True)

    with open(cli_path, 'w') as f:
        f.write(cli_script)

    # Make executable
    import os
    os.chmod(cli_path, 0o755)

    print(f"✅ Created CLI wrapper: {cli_path}")


def verify_installation():
    """Verify that everything is set up correctly."""
    print("\n🔍 Verifying installation...")

    checks = [
        (DB_PATH.exists(), "Database file"),
        ((Path.home() / ".openclaw/workspace/memory/model_pricing.json").exists(), "Model pricing config"),
        ((Path.home() / ".openclaw/workspace/memory/routing_topics.json").exists(), "Routing topics config"),
        ((Path.home() / ".openclaw/bin/mo-stats").exists(), "CLI wrapper"),
    ]

    all_passed = True
    for check, name in checks:
        status = "✅" if check else "❌"
        print(f"  {status} {name}")
        if not check:
            all_passed = False

    if all_passed:
        print("\n🎉 All checks passed! System is ready.")
    else:
        print("\n⚠️  Some checks failed. Run this script again.")

    return all_passed


def main():
    """Main entry point."""
    print("=" * 60)
    print("📦 MODEL ORCHESTRATOR - DATABASE INITIALIZATION")
    print("=" * 60)
    print()

    ensure_directories()
    create_database_schema()
    initialize_config_files()
    create_cli_wrapper()
    verify_installation()

    print("\n" + "=" * 60)
    print("Initialization complete!")
    print("=" * 60)
    print("\nNext steps:")
    print("  1. Add your API keys to environment variables")
    print("  2. Test with: mo-stats --help")
    print("  3. Start using the system normally")
    print()


if __name__ == "__main__":
    main()
