#!/usr/bin/env python3
"""
Real-Time Cost Monitor Module for Model Orchestrator v2.0

Tracks spending during active sessions, alerts before budget exceeded.
Provides daily cost reports and cheaper model recommendations.
Part of NexDev AI Coding Stack - Phase 4 Implementation
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

# Paths
DB_PATH = Path.home() / ".openclaw/workspace/memory/project_graph.db"
PRICING_PATH = Path.home() / ".openclaw/workspace/memory/model_pricing.json"
CONFIG_PATH = Path.home() / ".openclaw/workspace/memory/.mo_config.json"


@dataclass
class BudgetCheck:
    """Represents a budget check result."""
    within_budget: bool
    estimated_cost: float
    alerts: List[str]
    alternatives: List[Dict[str, Any]]


def load_model_pricing() -> Dict[str, Any]:
    """Load model pricing configuration."""
    try:
        with open(PRICING_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        return {"models": {}, "budget_limits": {}}


def load_config() -> Dict[str, Any]:
    """Load MO configuration."""
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


def calculate_query_cost(model_id: str, complexity: str = "medium") -> float:
    """
    Estimate cost for a query based on model and complexity.

    Args:
        model_id: Full model identifier
        complexity: Query complexity (simple, medium, complex, architectural)

    Returns:
        Estimated cost in USD
    """
    pricing = load_model_pricing()
    model_config = pricing.get("models", {}).get(model_id, {})

    input_cost = model_config.get("input_cost_per_million_tokens", 1.0)
    output_cost = model_config.get("output_cost_per_million_tokens", 2.0)

    # Token estimates by complexity
    token_estimates = {
        "simple": {"input": 100, "output": 200},
        "medium": {"input": 500, "output": 1000},
        "complex": {"input": 1000, "output": 3000},
        "architectural": {"input": 2000, "output": 5000}
    }

    estimate = token_estimates.get(complexity, token_estimates["medium"])
    tokens_input = estimate["input"]
    tokens_output = estimate["output"]

    total_cost = (tokens_input * input_cost / 1_000_000) + \
                 (tokens_output * output_cost / 1_000_000)

    return round(total_cost, 6)


def get_daily_cost(date: Optional[str] = None) -> Dict[str, Any]:
    """
    Get cost for specific date or today.

    Args:
        date: Date string in YYYY-MM-DD format

    Returns:
        Dictionary with daily cost info
    """
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT id, date, total_cost_usd, query_count, by_model, by_topic
        FROM daily_costs WHERE date = ?
    ''', (date,))

    row = cursor.fetchone()
    conn.close()

    if row and len(row) >= 6:
        return {
            "date": row[1],
            "total_cost_usd": row[2] or 0.0,
            "query_count": row[3] or 0,
            "by_model": json.loads(row[4]) if row[4] else {},
            "by_topic": json.loads(row[5]) if row[5] else {}
        }
    else:
        return {
            "date": date,
            "total_cost_usd": 0.0,
            "query_count": 0,
            "by_model": {},
            "by_topic": {},
            "message": "No costs recorded for this date"
        }


def get_today_cost() -> float:
    """Get total cost for today."""
    return get_daily_cost()["total_cost_usd"]


def check_budget(model_id: str, complexity: str = "medium") -> BudgetCheck:
    """
    Check if using specified model stays within budget.

    Args:
        model_id: Model to check
        complexity: Query complexity level

    Returns:
        BudgetCheck object with results
    """
    pricing = load_model_pricing()
    budget_limits = pricing.get("budget_limits", {})

    daily_max = budget_limits.get("daily_max_usd", 20.0)
    per_query_max = budget_limits.get("per_query_max_usd", 5.0)

    # Calculate estimated cost
    estimated_cost = calculate_query_cost(model_id, complexity)

    # Get today's current spend
    today_cost = get_today_cost()
    projected_cost = today_cost + estimated_cost

    alerts = []
    alternatives = []

    # Check against limits
    if estimated_cost > per_query_max:
        alerts.append(f"⚠️  Single query cost (${estimated_cost:.4f}) exceeds per-query limit (${per_query_max:.2f})")

    if projected_cost > daily_max:
        alerts.append(f"⚠️  Projected daily cost (${projected_cost:.2f}) exceeds daily limit (${daily_max:.2f})")
        alerts.append(f"   Remaining budget: ${max(0, daily_max - today_cost):.2f}")

        # Find cheaper alternatives
        alternatives = find_cheaper_models(model_id, max_cost=daily_max - today_cost)
    elif estimated_cost > 0.01:  # Warn for queries over $0.01
        remaining_pct = ((daily_max - projected_cost) / daily_max) * 100
        alerts.append(f"ℹ️  Query cost ${estimated_cost:.4f} ({remaining_pct:.0f}% budget remaining)")

    return BudgetCheck(
        within_budget=len(alerts) == 0 or all(not a.startswith("⚠️") for a in alerts),
        estimated_cost=estimated_cost,
        alerts=alerts,
        alternatives=alternatives
    )


def find_cheaper_models(current_model: str, max_cost: Optional[float] = None) -> List[Dict[str, Any]]:
    """
    Find cheaper alternative models that could handle the task.

    Args:
        current_model: Current model being considered
        max_cost: Maximum cost per query (defaults to per-query limit)

    Returns:
        List of cheaper model options
    """
    pricing = load_model_pricing()
    models_config = pricing.get("models", {})

    current_tier = models_config.get(current_model, {}).get("tier", "unknown")

    # Define tier order (cheapest first)
    tier_order = ["ultra-cheap", "cheap", "medium", "expert", "nuclear"]
    current_tier_idx = tier_order.index(current_tier) if current_tier in tier_order else 2

    # Find lower tiers
    cheaper_options = []

    for tier in tier_order[:current_tier_idx]:
        for model_id, config in models_config.items():
            if config.get("tier") == tier:
                model_cost = calculate_query_cost(model_id, "medium")
                if max_cost is None or model_cost <= max_cost:
                    cheaper_options.append({
                        "model_id": model_id,
                        "model_name": model_id.split('/')[-1],
                        "tier": tier,
                        "estimated_cost": model_cost,
                        "savings": calculate_query_cost(current_model, "medium") - model_cost,
                        "use_cases": config.get("use_cases", [])
                    })

    # Sort by savings (descending)
    cheaper_options.sort(key=lambda x: x['savings'], reverse=True)

    return cheaper_options[:3]  # Return top 3 alternatives


def log_query(model_id: str, tokens_in: int, tokens_out: int, topic: str) -> float:
    """
    Log a completed query and update daily totals.

    Args:
        model_id: Model that was used
        tokens_in: Input token count
        tokens_out: Output token count
        topic: Topic of the query

    Returns:
        Actual cost incurred
    """
    pricing = load_model_pricing()
    model_config = pricing.get("models", {}).get(model_id, {})

    input_cost = model_config.get("input_cost_per_million_tokens", 1.0)
    output_cost = model_config.get("output_cost_per_million_tokens", 2.0)

    actual_cost = (tokens_in * input_cost / 1_000_000) + \
                  (tokens_out * output_cost / 1_000_000)

    today = datetime.now().strftime("%Y-%m-%d")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Update performance_logs table (already done by performance_logger.py)
    # Just update daily_costs summary here

    cursor.execute('SELECT * FROM daily_costs WHERE date = ?', (today,))
    existing = cursor.fetchone()

    if existing:
        new_total = existing[2] + actual_cost
        new_count = existing[3] + 1

        # Update by_model breakdown
        by_model = json.loads(existing[4]) if existing[4] else {}
        by_model[model_id] = by_model.get(model_id, 0) + actual_cost

        # Update by_topic breakdown
        by_topic = json.loads(existing[5]) if existing[5] else {}
        by_topic[topic] = by_topic.get(topic, 0) + actual_cost

        cursor.execute('''
            UPDATE daily_costs
            SET total_cost_usd = ?, query_count = ?, by_model = ?, by_topic = ?
            WHERE date = ?
        ''', (new_total, new_count, json.dumps(by_model), json.dumps(by_topic), today))
    else:
        # Create new entry
        by_model = json.dumps({model_id: actual_cost})
        by_topic = json.dumps({topic: actual_cost})

        cursor.execute('''
            INSERT INTO daily_costs (date, total_cost_usd, query_count, by_model, by_topic)
            VALUES (?, ?, ?, ?, ?)
        ''', (today, actual_cost, 1, by_model, by_topic))

    conn.commit()
    conn.close()

    return round(actual_cost, 6)


def get_daily_cost_report() -> Dict[str, Any]:
    """
    Generate comprehensive daily cost report.

    Returns:
        Dictionary with full cost report
    """
    pricing = load_model_pricing()
    budget_limits = pricing.get("budget_limits", {})

    today = datetime.now().strftime("%Y-%m-%d")
    daily_data = get_daily_cost(today)

    # Get last 7 days trend
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT date, total_cost_usd, query_count
        FROM daily_costs
        WHERE date >= date('now', '-7 days')
        ORDER BY date ASC
    ''')

    weekly_data = [{"date": row[0], "cost": row[1], "queries": row[2]} for row in cursor.fetchall()]
    conn.close()

    # Calculate averages
    total_cost = sum(d['cost'] for d in weekly_data)
    total_queries = sum(d['queries'] for d in weekly_data)
    avg_daily_cost = total_cost / len(weekly_data) if weekly_data else 0
    avg_cost_per_query = total_cost / total_queries if total_queries > 0 else 0

    # Monthly projection
    daily_max = budget_limits.get("daily_max_usd", 20.0)
    monthly_projection = avg_daily_cost * 30 if avg_daily_cost > 0 else daily_max * 30

    # Budget status
    remaining_budget = daily_max - daily_data['total_cost_usd']
    budget_status = "green" if remaining_budget > daily_max * 0.5 else \
                   "yellow" if remaining_budget > daily_max * 0.2 else \
                   "red"

    return {
        "report_date": today,
        "daily_summary": {
            "total_spent": daily_data['total_cost_usd'],
            "query_count": daily_data['query_count'],
            "avg_cost_per_query": daily_data['total_cost_usd'] / daily_data['query_count'] if daily_data['query_count'] > 0 else 0,
            "remaining_budget": remaining_budget,
            "budget_status": budget_status
        },
        "weekly_trend": weekly_data,
        "statistics": {
            "total_weekly_cost": total_cost,
            "avg_daily_cost": avg_daily_cost,
            "avg_cost_per_query": avg_cost_per_query,
            "monthly_projection": monthly_projection,
            "on_track_for_monthly_budget": monthly_projection <= 600  # $20/day * 30
        },
        "breakdown": {
            "by_model": daily_data.get('by_model', {}),
            "by_topic": daily_data.get('by_topic', {})
        },
        "alerts": []
    }


def get_cost_efficiency_ranking() -> List[Dict[str, Any]]:
    """
    Rank models by cost-efficiency (queries completed per dollar).

    Returns:
        List of models sorted by efficiency
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as queries,
            SUM(cost_usd) as total_cost,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate
        FROM performance_logs
        GROUP BY model_used
        HAVING total_cost > 0
        ORDER BY (queries / total_cost) DESC
    ''')

    results = cursor.fetchall()
    conn.close()

    ranking = []
    for model, queries, total_cost, success_rate in results:
        efficiency = queries / total_cost if total_cost > 0 else 0
        avg_cost = total_cost / queries if queries > 0 else 0

        ranking.append({
            "rank": len(ranking) + 1,
            "model_id": model,
            "model_name": model.split('/')[-1],
            "queries": queries,
            "total_cost": total_cost,
            "avg_cost_per_query": avg_cost,
            "success_rate": success_rate,
            "efficiency_score": efficiency,
            "value_label": "excellent" if efficiency > 5000 else "good" if efficiency > 1000 else "moderate"
        })

    return ranking


def set_daily_budget(amount_usd: float) -> bool:
    """
    Set custom daily budget limit.

    Args:
        amount_usd: New daily budget in USD

    Returns:
        True if successful
    """
    try:
        config = load_model_pricing()
        config.setdefault("budget_limits", {})["daily_max_usd"] = amount_usd

        with open(PRICING_PATH, 'w') as f:
            json.dump(config, f, indent=2)

        return True
    except Exception as e:
        print(f"Error setting budget: {e}")
        return False


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("COST MONITOR - Self Test")
    print("=" * 60)

    print("\n📊 Testing cost estimation:\n")

    # Test cost calculation
    models_to_test = [
        ("google/gemini-2.0-flash-lite", "simple"),
        ("alibaba-sg/qwen3.5-122b-a10b", "medium"),
        ("anthropic/claude-sonnet-4-6", "complex"),
    ]

    print("Cost Estimates:")
    for model, complexity in models_to_test:
        cost = calculate_query_cost(model, complexity)
        print(f"  {model.split('/')[-1]:<30} ({complexity:<12}): ${cost:.6f}")

    print("\n" + "-" * 60)

    # Test budget check
    print("\nBudget Checks:\n")

    test_checks = [
        ("alibaba-sg/qwen3.5-122b-a10b", "medium"),
        ("anthropic/claude-opus-4-6", "architectural"),
    ]

    for model, complexity in test_checks:
        check = check_budget(model, complexity)
        print(f"Model: {model.split('/')[-1]} ({complexity})")
        print(f"  Within budget: {check.within_budget}")
        print(f"  Estimated cost: ${check.estimated_cost:.6f}")

        if check.alerts:
            print(f"  Alerts:")
            for alert in check.alerts:
                print(f"    {alert}")

        if check.alternatives:
            print(f"  Cheaper alternatives:")
            for alt in check.alternatives:
                print(f"    - {alt['model_name']} (saves ${alt['savings']:.4f})")
        print()

    # Test daily report
    print("-" * 60)
    print("\nDaily Cost Report:\n")
    report = get_daily_cost_report()

    print(f"Date: {report['report_date']}")
    print(f"Total spent: ${report['daily_summary']['total_spent']:.4f}")
    print(f"Query count: {report['daily_summary']['query_count']}")
    print(f"Remaining budget: ${report['daily_summary']['remaining_budget']:.2f}")
    print(f"Budget status: {report['daily_summary']['budget_status']}")
    print(f"\nWeekly average: ${report['statistics']['avg_daily_cost']:.4f}/day")
    print(f"Monthly projection: ${report['statistics']['monthly_projection']:.2f}")

    print("\n" + "=" * 60)
    print("Test complete!")
