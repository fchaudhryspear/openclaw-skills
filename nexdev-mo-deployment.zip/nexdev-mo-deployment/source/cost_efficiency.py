#!/usr/bin/env python3
"""
Cost Efficiency Analyzer Module for Model Orchestrator v2.0

Balances quality vs cost per topic to maximize value.
Finds most efficient models using success_rate / avg_cost formula.
Part of NexDev AI Coding Stack - Phase 1 Implementation
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

# Database path
DB_PATH = Path.home() / ".openclaw/workspace/memory/project_graph.db"

# Model pricing config
PRICING_PATH = Path.home() / ".openclaw/workspace/memory/model_pricing.json"


@dataclass
class ModelEfficiency:
    """Represents a model's efficiency metrics."""
    model_id: str
    success_rate: float
    avg_cost_per_query: float
    efficiency_score: float
    usage_count: int
    recommendation: str


def load_model_pricing() -> Dict[str, Any]:
    """Load model pricing configuration."""
    try:
        with open(PRICING_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        # Return minimal config if file doesn't exist
        return {
            "models": {
                "google/gemini-2.0-flash-lite": {
                    "input_cost_per_million_tokens": 0.10,
                    "output_cost_per_million_tokens": 0.40
                }
            },
            "budget_limits": {
                "daily_max_usd": 20.0,
                "per_query_max_usd": 5.0
            }
        }


def calculate_cost(model_id: str, tokens_input: int, tokens_output: int) -> float:
    """
    Calculate estimated cost for a query.

    Args:
        model_id: Full model identifier
        tokens_input: Input token count
        tokens_output: Output token count

    Returns:
        Estimated cost in USD
    """
    pricing = load_model_pricing()
    model_config = pricing.get("models", {}).get(model_id, {})

    input_cost = model_config.get("input_cost_per_million_tokens", 1.0)
    output_cost = model_config.get("output_cost_per_million_tokens", 2.0)

    total_cost = (tokens_input * input_cost / 1_000_000) + \
                 (tokens_output * output_cost / 1_000_000)

    return round(total_cost, 6)


def get_efficiency_formula(success_rate: float, avg_cost: float) -> float:
    """
    Calculate efficiency score using success_rate / avg_cost.

    Args:
        success_rate: Success rate (0-1)
        avg_cost: Average cost per query

    Returns:
        Efficiency score (higher is better)
    """
    if avg_cost <= 0:
        # Avoid division by zero - use very high efficiency for free models
        return success_rate * 10000

    return success_rate / avg_cost


def get_cost_efficient_model(topic: str, max_cost_usd: float = 5.0,
                            min_success_rate: float = 0.80,
                            min_usage: int = 2) -> Optional[ModelEfficiency]:
    """
    Get most cost-efficient model for a topic within budget.

    Args:
        topic: Topic name to query
        max_cost_usd: Maximum acceptable cost per query
        min_success_rate: Minimum acceptable success rate
        min_usage: Minimum number of queries required

    Returns:
        ModelEfficiency object or None if no suitable model found
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            SUM(cost_usd) / COUNT(*) as avg_cost_per_query
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        HAVING usage_count >= ? AND success_rate >= ? AND avg_cost_per_query <= ?
        ORDER BY avg_cost_per_query ASC
        LIMIT 1
    ''', (topic, min_usage, min_success_rate, max_cost_usd))

    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    model_id, usage_count, success_rate, avg_cost = row
    efficiency = get_efficiency_formula(success_rate, avg_cost)

    return ModelEfficiency(
        model_id=model_id,
        success_rate=success_rate,
        avg_cost_per_query=avg_cost,
        efficiency_score=efficiency,
        usage_count=usage_count,
        recommendation="budget-optimized"
    )


def find_cheapest_viable_model(topic: str, min_success_rate: float = 0.75) -> Optional[ModelEfficiency]:
    """
    Find cheapest model that meets minimum success threshold.

    Args:
        topic: Topic name to query
        min_success_rate: Minimum acceptable success rate

    Returns:
        ModelEfficiency object or None
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            SUM(cost_usd) / COUNT(*) as avg_cost_per_query
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        HAVING success_rate >= ?
        ORDER BY avg_cost_per_query ASC
        LIMIT 1
    ''', (topic, min_success_rate))

    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    model_id, usage_count, success_rate, avg_cost = row
    efficiency = get_efficiency_formula(success_rate, avg_cost)

    return ModelEfficiency(
        model_id=model_id,
        success_rate=success_rate,
        avg_cost_per_query=avg_cost,
        efficiency_score=efficiency,
        usage_count=usage_count,
        recommendation="cheapest-viable"
    )


def find_quality_model(topic: str, max_cost_usd: float = 10.0,
                      min_success_rate: float = 0.90) -> Optional[ModelEfficiency]:
    """
    Find highest-quality model within budget (cost is secondary).

    Args:
        topic: Topic name to query
        max_cost_usd: Maximum acceptable cost per query
        min_success_rate: Minimum acceptable success rate

    Returns:
        ModelEfficiency object or None
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            SUM(cost_usd) / COUNT(*) as avg_cost_per_query
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        HAVING success_rate >= ? AND avg_cost_per_query <= ?
        ORDER BY success_rate DESC
        LIMIT 1
    ''', (topic, min_success_rate, max_cost_usd))

    row = cursor.fetchone()
    conn.close()

    if not row:
        return None

    model_id, usage_count, success_rate, avg_cost = row
    efficiency = get_efficiency_formula(success_rate, avg_cost)

    return ModelEfficiency(
        model_id=model_id,
        success_rate=success_rate,
        avg_cost_per_query=avg_cost,
        efficiency_score=efficiency,
        usage_count=usage_count,
        recommendation="quality-first"
    )


def analyze_topic_cost_efficiency(topic: str) -> Dict[str, Any]:
    """
    Full cost-efficiency analysis for a topic.

    Args:
        topic: Topic name to analyze

    Returns:
        Dictionary with complete analysis
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Overall stats
    cursor.execute('''
        SELECT
            COUNT(*) as total_queries,
            SUM(cost_usd) as total_spent
        FROM performance_logs
        WHERE topic = ?
    ''', (topic,))

    overall = cursor.fetchone()

    # By model breakdown with efficiency scores
    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) / COUNT(*) as avg_cost_per_query,
            SUM(cost_usd) as total_cost
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        ORDER BY usage_count DESC
    ''', (topic,))

    models_data = []
    for row in cursor.fetchall():
        model_id, usage, success_rate, confidence, avg_cost, total_cost = row
        efficiency = get_efficiency_formula(success_rate, avg_cost) if avg_cost > 0 else success_rate * 10000

        models_data.append({
            "model_id": model_id,
            "model_name": model_id.split('/')[-1],
            "usage_count": usage,
            "success_rate": success_rate,
            "avg_confidence": confidence,
            "avg_cost_per_query": avg_cost,
            "total_cost": total_cost,
            "efficiency_score": efficiency,
            "cost_distribution": "low" if avg_cost < 0.01 else "medium" if avg_cost < 0.1 else "high"
        })

    conn.close()

    # Find best efficiency model
    best_efficiency = max(models_data, key=lambda x: x['efficiency_score']) if models_data else None

    return {
        "topic": topic,
        "total_queries": overall[0] if overall else 0,
        "total_spent": overall[1] if overall else 0,
        "models_tracked": len(models_data),
        "best_efficiency_model": best_efficiency["model_id"] if best_efficiency else None,
        "best_efficiency_score": best_efficiency["efficiency_score"] if best_efficiency else 0,
        "comparison": sorted(models_data, key=lambda x: x['efficiency_score'], reverse=True),
        "summary": {
            "min_avg_cost": min(m['avg_cost_per_query'] for m in models_data) if models_data else 0,
            "max_avg_cost": max(m['avg_cost_per_query'] for m in models_data) if models_data else 0,
            "avg_confidence": sum(m['avg_confidence'] for m in models_data) / len(models_data) if models_data else 0
        }
    }


def compare_models_for_topic(topic: str) -> List[Dict[str, Any]]:
    """
    Compare all models used for a topic side-by-side.

    Args:
        topic: Topic name to compare

    Returns:
        Sorted list of model comparisons
    """
    analysis = analyze_topic_cost_efficiency(topic)
    return analysis.get('comparison', [])


def get_monthly_savings_projection(topic: str, monthly_queries: int = 100) -> Dict[str, Any]:
    """
    Project monthly savings based on current cost-efficiency.

    Args:
        topic: Topic name to project
        monthly_queries: Estimated monthly query volume

    Returns:
        Dictionary with savings projection
    """
    analysis = analyze_topic_cost_efficiency(topic)

    if not analysis['models_tracked']:
        return {
            "topic": topic,
            "message": "No historical data for projections",
            "monthly_queries": monthly_queries
        }

    # Find average and optimal costs
    avg_cost = analysis['summary']['min_avg_cost']
    baseline_cost = 5.0  # Assumed cost without optimization (Opus-only)

    projected_optimal = avg_cost * monthly_queries
    projected_baseline = baseline_cost * monthly_queries
    projected_savings = projected_baseline - projected_optimal
    savings_percentage = (projected_savings / projected_baseline) * 100 if projected_baseline > 0 else 0

    return {
        "topic": topic,
        "monthly_queries": monthly_queries,
        "current_avg_cost_per_query": avg_cost,
        "baseline_assumption": baseline_cost,
        "projected_monthly_cost_optimized": projected_optimal,
        "projected_monthly_cost_baseline": projected_baseline,
        "projected_monthly_savings": projected_savings,
        "savings_percentage": savings_percentage,
        "projected_annual_savings": projected_savings * 12
    }


def get_budget_recommendation(topic: str, budget_remaining: float) -> Dict[str, Any]:
    """
    Get model recommendation based on remaining daily budget.

    Args:
        topic: Topic name to query
        budget_remaining: Remaining budget for today

    Returns:
        Dictionary with recommendation and alternatives
    """
    # Try to find model within budget
    cheap_model = get_cost_efficient_model(topic, max_cost_usd=min(budget_remaining, 5.0))

    # Also get quality option
    quality_model = find_quality_model(topic, max_cost_usd=min(budget_remaining * 2, 10.0))

    recommendations = []

    if cheap_model:
        recommendations.append({
            "type": "budget-friendly",
            **{k: v for k, v in vars(cheap_model).items()}
        })

    if quality_model:
        recommendations.append({
            "type": "quality-focused",
            **{k: v for k, v in vars(quality_model).items()}
        })

    return {
        "topic": topic,
        "budget_remaining": budget_remaining,
        "recommendations": recommendations,
        "within_budget": bool(recommendations)
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("COST EFFICIENCY ANALYZER - Self Test")
    print("=" * 60)

    # Create some test data first if database exists
    print("\n📊 Testing cost efficiency calculations:\n")

    # Test efficiency formula
    test_cases = [
        {"success": 1.0, "cost": 0.001, "expected_score": 1000},
        {"success": 0.9, "cost": 0.01, "expected_score": 90},
        {"success": 0.8, "cost": 0.10, "expected_score": 8},
        {"success": 0.95, "cost": 0.05, "expected_score": 19},
    ]

    print("Test 1: Efficiency formula\n")
    for tc in test_cases:
        result = get_efficiency_formula(tc["success"], tc["cost"])
        status = "✅" if abs(result - tc["expected_score"]) < 1 else "⚠️"
        print(f"{status} Success: {tc['success']:.0%}, Cost: ${tc['cost']:.4f}")
        print(f"   Efficiency score: {result:.1f} (expected ~{tc['expected_score']})")
        print()

    # Test full analysis if we have data
    print("Test 2: Topic cost-efficiency analysis\n")

    # Check if lambda-development topic exists in our earlier tests
    try:
        analysis = analyze_topic_cost_efficiency("lambda-development")
        if analysis['total_queries'] > 0:
            print(f"Topic: {analysis['topic']}")
            print(f"Total queries: {analysis['total_queries']}")
            print(f"Total spent: ${analysis['total_spent']:.4f}")
            print(f"Models tracked: {analysis['models_tracked']}")

            if analysis['comparison']:
                print("\nModel rankings by efficiency:")
                for i, model in enumerate(analysis['comparison'][:3], 1):
                    print(f"  {i}. {model['model_name']}")
                    print(f"     Efficiency: {model['efficiency_score']:.1f}")
                    print(f"     Success rate: {model['success_rate']:.0%}")
                    print(f"     Avg cost: ${model['avg_cost_per_query']:.4f}")
                    print()
        else:
            print("   No data for 'lambda-development' topic")
            print("   Run performance_logger.py tests first to populate data")
    except Exception as e:
        print(f"   Error: {e}")

    print("=" * 60)
    print("Test complete!")
