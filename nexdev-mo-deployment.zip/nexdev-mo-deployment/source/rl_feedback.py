#!/usr/bin/env python3
"""
Reinforcement Learning from User Feedback Module for Model Orchestrator v2.0

Learns from explicit user ratings (1-5 stars) to improve future routing decisions.
Implements time-weighted scoring and decay for older feedback.
Part of NexDev AI Coding Stack - Phase 5 Implementation
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

# Database path
DB_PATH = Path.home() / ".openclaw/workspace/memory/project_graph.db"


@dataclass
class FeedbackRecord:
    """Represents a single user feedback entry."""
    id: int
    timestamp: str
    query_id: str
    topic: str
    model_used: str
    rating: int
    comments: str


def record_feedback(query_id: str, topic: str, model_used: str,
                   rating: int, comments: str = "") -> Dict[str, Any]:
    """
    Record user feedback for a response.

    Args:
        query_id: Unique identifier for the query
        topic: Topic detected for this query
        model_used: Model that generated the response
        rating: Rating from 1-5 stars
        comments: Optional user comments

    Returns:
        Dictionary with recording result
    """
    if not (1 <= rating <= 5):
        return {"status": "error", "message": "Rating must be between 1 and 5"}

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO user_feedback
            (query_id, topic, model_used, rating, comments)
            VALUES (?, ?, ?, ?, ?)
        ''', (query_id, topic, model_used, rating, comments))

        feedback_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return {
            "status": "recorded",
            "feedback_id": feedback_id,
            "topic": topic,
            "model_used": model_used,
            "rating": rating
        }

    except Exception as e:
        return {"status": "error", "message": str(e)}


def get_model_preference(topic: str, days_window: int = 30) -> Optional[Dict[str, Any]]:
    """
    Get best model for topic based on weighted user ratings.

    Args:
        topic: Topic to analyze
        days_window: Look back only this many days

    Returns:
        Dictionary with preferred model info or None
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cutoff_date = (datetime.now() - timedelta(days=days_window)).isoformat()[:19]

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as feedback_count,
            AVG(rating) as avg_rating,
            SUM(
                CASE
                    WHEN julianday('now') - julianday(timestamp) <= 7 THEN 1.0
                    WHEN julianday('now') - julianday(timestamp) <= 14 THEN 0.8
                    ELSE 0.6
                END
            ) as weighted_score_sum,
            SUM(
                rating *
                CASE
                    WHEN julianday('now') - julianday(timestamp) <= 7 THEN 1.0
                    WHEN julianday('now') - julianday(timestamp) <= 14 THEN 0.8
                    ELSE 0.6
                END
            ) as weighted_rating_sum
        FROM user_feedback
        WHERE topic = ? AND timestamp >= ?
        GROUP BY model_used
        ORDER BY weighted_score_sum DESC
    ''', (topic, cutoff_date))

    results = cursor.fetchall()
    conn.close()

    if not results:
        return None

    # Calculate weighted average rating
    best = results[0]
    model_id, count, avg_rating, weight_sum, weighted_rating_sum = best

    weighted_avg_rating = weighted_rating_sum / weight_sum if weight_sum > 0 else avg_rating

    return {
        "model_id": model_id,
        "feedback_count": count,
        "avg_rating": avg_rating,
        "weighted_rating": weighted_avg_rating,
        "recommendation_strength": _get_strength_label(count, weighted_avg_rating),
        "days_window": days_window
    }


def _get_strength_label(count: int, avg_rating: float) -> str:
    """Get recommendation strength label based on data quality."""
    if count >= 10 and avg_rating >= 4.5:
        return "strong"
    elif count >= 5 and avg_rating >= 4.0:
        return "moderate"
    elif count >= 2:
        return "weak"
    else:
        return "insufficient_data"


def compare_models_for_topic(topic: str) -> List[Dict[str, Any]]:
    """
    Compare all models rated for a topic.

    Args:
        topic: Topic to analyze

    Returns:
        List of model comparisons sorted by rating
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as feedback_count,
            AVG(rating) as avg_rating,
            MIN(rating) as min_rating,
            MAX(rating) as max_rating,
            SUM(CASE WHEN rating >= 4 THEN 1 ELSE 0 END) as positive_count,
            SUM(CASE WHEN rating <= 2 THEN 1 ELSE 0 END) as negative_count
        FROM user_feedback
        WHERE topic = ?
        GROUP BY model_used
        ORDER BY avg_rating DESC, feedback_count DESC
    ''', (topic,))

    results = cursor.fetchall()
    conn.close()

    comparisons = []
    for row in results:
        model_id, count, avg, min_r, max_r, positive, negative = row
        positive_pct = (positive / count * 100) if count > 0 else 0

        comparisons.append({
            "model_id": model_id,
            "model_name": model_id.split('/')[-1],
            "feedback_count": count,
            "avg_rating": avg,
            "min_rating": min_r,
            "max_rating": max_r,
            "positive_percentage": positive_pct,
            "positive_count": positive,
            "negative_count": negative,
            "star_distribution": _get_star_distribution(model_id, topic)
        })

    return comparisons


def _get_star_distribution(model_id: str, topic: str) -> Dict[int, int]:
    """Get count of each star rating."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT rating, COUNT(*)
        FROM user_feedback
        WHERE model_used = ? AND topic = ?
        GROUP BY rating
        ORDER BY rating
    ''', (model_id, topic))

    distribution = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for row in cursor.fetchall():
        rating, count = row
        distribution[rating] = count

    conn.close()
    return distribution


def get_feedback_trends(topic: Optional[str] = None, days: int = 7) -> List[Dict[str, Any]]:
    """
    Get feedback trends over time.

    Args:
        topic: Optional topic filter
        days: Number of days to look back

    Returns:
        List of daily trend entries
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    topic_clause = f"AND topic = '{topic}'" if topic else ""
    cutoff_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

    cursor.execute(f'''
        SELECT
            date(timestamp) as day,
            COUNT(*) as feedback_count,
            AVG(rating) as avg_rating
        FROM user_feedback
        WHERE timestamp >= ? {topic_clause}
        GROUP BY date(timestamp)
        ORDER BY day DESC
    ''', (cutoff_date,))

    results = cursor.fetchall()
    conn.close()

    return [
        {"date": row[0], "feedback_count": row[1], "avg_rating": row[2]}
        for row in results
    ]


def get_low_rated_models(min_count: int = 3, max_rating: float = 3.0) -> List[Dict[str, Any]]:
    """
    Find models with consistently low ratings.

    Args:
        min_count: Minimum feedback count to consider
        max_rating: Maximum average rating to flag as problematic

    Returns:
        List of underperforming models
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            topic,
            COUNT(*) as feedback_count,
            AVG(rating) as avg_rating
        FROM user_feedback
        GROUP BY model_used, topic
        HAVING feedback_count >= ? AND avg_rating <= ?
        ORDER BY avg_rating ASC
    ''', (min_count, max_rating))

    results = cursor.fetchall()
    conn.close()

    problematic = []
    for model, topic, count, avg_rating in results:
        problematic.append({
            "model_id": model,
            "topic": topic,
            "feedback_count": count,
            "avg_rating": avg_rating,
            "action_recommended": f"Downweight {model.split('/')[-1]} for {topic}"
        })

    return problematic


def generate_recommendations() -> Dict[str, Any]:
    """
    Generate actionable recommendations based on feedback data.

    Returns:
        Dictionary with recommendations
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Get topics with enough feedback
    cursor.execute('''
        SELECT topic, COUNT(*) as total_feedback
        FROM user_feedback
        GROUP BY topic
        HAVING total_feedback >= 5
        ORDER BY total_feedback DESC
    ''')

    topics_with_data = cursor.fetchall()

    recommendations = {
        "high_confidence_routes": [],
        "models_to_downweight": [],
        "topics_needing_more_data": [],
        "summary": {}
    }

    for topic, _ in topics_with_data:
        pref = get_model_preference(topic, days_window=30)
        if pref and pref["recommendation_strength"] == "strong":
            recommendations["high_confidence_routes"].append({
                "topic": topic,
                "recommended_model": pref["model_id"],
                "confidence": pref["weighted_rating"],
                "feedback_count": pref["feedback_count"]
            })

    # Find problematic models
    problematic = get_low_rated_models()
    if problematic:
        recommendations["models_to_downweight"] = [
            {
                "model_id": p["model_id"],
                "topic": p["topic"],
                "reason": f"Low avg rating ({p['avg_rating']:.1f}/5) from {p['feedback_count']} feedbacks"
            }
            for p in problematic
        ]

    # Topics needing more feedback
    cursor.execute('''
        SELECT topic, COUNT(*) as count
        FROM user_feedback
        GROUP BY topic
        HAVING count < 5
    ''')
    sparse_topics = cursor.fetchall()
    recommendations["topics_needing_more_data"] = [
        {"topic": t[0], "current_feedback": t[1], "target": 5}
        for t in sparse_topics
    ]

    conn.close()

    # Summary stats
    cursor.execute('SELECT COUNT(*) FROM user_feedback')
    total_feedback = cursor.fetchone()[0]

    cursor.execute('SELECT AVG(rating) FROM user_feedback')
    global_avg = cursor.fetchone()[0]

    recommendations["summary"] = {
        "total_feedback": total_feedback,
        "global_avg_rating": global_avg if global_avg else 0,
        "high_confidence_routes": len(recommendations["high_confidence_routes"]),
        "problems_identified": len(recommendations["models_to_downweight"])
    }

    return recommendations


def reset_topic_feedback(topic: str) -> int:
    """
    Clear feedback data for a specific topic.

    Args:
        topic: Topic to clear

    Returns:
        Number of records deleted
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('DELETE FROM user_feedback WHERE topic = ?', (topic,))
    deleted = cursor.rowcount

    conn.commit()
    conn.close()

    return deleted


def get_feedback_stats() -> Dict[str, Any]:
    """Get overall feedback statistics."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM user_feedback')
    total = cursor.fetchone()[0]

    cursor.execute('SELECT AVG(rating) FROM user_feedback')
    avg_rating = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(DISTINCT topic) FROM user_feedback')
    topics = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(DISTINCT model_used) FROM user_feedback')
    models = cursor.fetchone()[0]

    # Rating distribution
    cursor.execute('''
        SELECT rating, COUNT(*)
        FROM user_feedback
        GROUP BY rating
        ORDER BY rating
    ''')
    distribution = dict(cursor.fetchall())

    conn.close()

    return {
        "total_feedback": total,
        "avg_rating": avg_rating if avg_rating else 0,
        "topics_tracked": topics,
        "models_tracked": models,
        "distribution": {str(k): v for k, v in distribution.items()}
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("RL FEEDBACK - Self Test")
    print("=" * 60)

    print("\n📊 Testing feedback system:\n")

    # Record some test feedback
    test_feedback = [
        ("q1", "lambda-development", "alibaba-sg/qwen3.5-122b-a10b", 5, "Perfect solution!"),
        ("q2", "lambda-development", "alibaba-sg/qwen3.5-122b-a10b", 5, "Works great"),
        ("q3", "lambda-development", "alibaba-sg/qwen3.5-122b-a10b", 4, "Good but verbose"),
        ("q4", "api-gateway-cors", "google/gemini-2.5-flash", 4, "Helpful answer"),
        ("q5", "testing-setup", "alibaba-sg/qwen-coder", 5, "Excellent test coverage"),
    ]

    print("Recording test feedback:")
    for query_id, topic, model, rating, comment in test_feedback:
        result = record_feedback(query_id, topic, model, rating, comment)
        status = "✅" if result["status"] == "recorded" else "❌"
        print(f"  {status} {topic} → {model.split('/')[-1]} ({rating}/5)")

    print("\n" + "-" * 60)

    # Check preferences
    print("\nModel Preferences:\n")

    topics = ["lambda-development", "api-gateway-cors", "testing-setup"]
    for topic in topics:
        pref = get_model_preference(topic)
        if pref:
            print(f"Topic: {topic}")
            print(f"  Preferred: {pref['model_id'].split('/')[-1]}")
            print(f"  Weighted rating: {pref['weighted_rating']:.2f}/5")
            print(f"  Feedback count: {pref['feedback_count']}")
            print(f"  Strength: {pref['recommendation_strength']}")
            print()

    # Compare models
    print("-" * 60)
    print("\nModel Comparisons:\n")

    comparison = compare_models_for_topic("lambda-development")
    if comparison:
        for m in comparison:
            print(f"Model: {m['model_name']}")
            print(f"  Avg rating: {m['avg_rating']:.2f}/5")
            print(f"  Positive: {m['positive_percentage']:.0f}%")
            print(f"  Distribution: {m['star_distribution']}")
            print()

    # Recommendations
    print("-" * 60)
    print("\nGenerated Recommendations:\n")

    recs = generate_recommendations()
    print(f"High confidence routes: {len(recs['high_confidence_routes'])}")
    for route in recs['high_confidence_routes']:
        print(f"  - {route['topic']} → {route['recommended_model'].split('/')[-1]}")

    print(f"\nModels to downweight: {len(recs['models_to_downweight'])}")
    for model in recs['models_to_downweight']:
        print(f"  - {model['model_id'].split('/')[-1]} for {model['topic']}")

    print("\nFeedback Stats:")
    stats = get_feedback_stats()
    print(f"  Total feedback: {stats['total_feedback']}")
    print(f"  Average rating: {stats['avg_rating']:.2f}/5")
    print(f"  Topics tracked: {stats['topics_tracked']}")

    print("\n" + "=" * 60)
    print("Test complete!")
