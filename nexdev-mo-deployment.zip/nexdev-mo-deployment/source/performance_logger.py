#!/usr/bin/env python3
"""
Performance Logger Module for Model Orchestrator v2.0

Auto-logs query results to build learning database.
Tracks success rates, costs, and confidence per topic/model combination.
Part of NexDev AI Coding Stack - Phase 1 Implementation
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict

# Database path
DB_PATH = Path.home() / ".openclaw/workspace/memory/project_graph.db"

# Performance JSON backup (for quick access without DB queries)
PERF_JSON_PATH = Path.home() / ".openclaw/workspace/memory/model_performance.json"


@dataclass
class PerformanceRecord:
    """Represents a single logged query result."""
    id: Optional[int]
    timestamp: str
    topic: str
    model_used: str
    success: bool
    tokens_input: int
    tokens_output: int
    cost_usd: float
    confidence_score: float
    query_text: str
    response_summary: str


def init_database():
    """Initialize SQLite database if it doesn't exist."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS performance_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            topic TEXT NOT NULL,
            model_used TEXT NOT NULL,
            success BOOLEAN,
            tokens_input INTEGER,
            tokens_output INTEGER,
            cost_usd REAL,
            confidence_score REAL,
            query_text TEXT,
            response_summary TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS daily_costs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date DATE UNIQUE,
            total_cost_usd REAL DEFAULT 0,
            query_count INTEGER DEFAULT 0,
            by_model TEXT,
            by_topic TEXT
        )
    ''')

    conn.commit()
    conn.close()


def log_query_result(topic: str, model_used: str, success: bool,
                    tokens_input: int, tokens_output: int,
                    cost_usd: float = 0.0, confidence_score: float = 1.0,
                    query_text: str = "", response_summary: str = "") -> Dict[str, Any]:
    """
    Log a query result to the performance database.

    Args:
        topic: Detected topic from query
        model_used: Full model identifier (e.g., "alibaba-sg/qwen3.5-122b-a10b")
        success: Whether the query was successful
        tokens_input: Input token count
        tokens_output: Output token count
        cost_usd: Actual cost in USD
        confidence_score: Self-assessed confidence (0-1)
        query_text: Original query text
        response_summary: Brief summary of response

    Returns:
        Dictionary with logging result
    """
    # Ensure database exists
    init_database()

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO performance_logs
            (topic, model_used, success, tokens_input, tokens_output,
             cost_usd, confidence_score, query_text, response_summary)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (topic, model_used, success, tokens_input, tokens_output,
              cost_usd, confidence_score, query_text[:1000], response_summary[:1000]))

        record_id = cursor.lastrowid
        conn.commit()
        conn.close()

        # Update daily cost
        _update_daily_cost(cost_usd)

        return {
            "status": "logged",
            "record_id": record_id,
            "topic": topic,
            "model_used": model_used,
            "cost_usd": cost_usd
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "topic": topic,
            "model_used": model_used
        }


def _update_daily_cost(cost_usd: float):
    """Update daily cost tracking table."""
    today = datetime.now().strftime("%Y-%m-%d")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Check if today's entry exists
    cursor.execute('SELECT * FROM daily_costs WHERE date = ?', (today,))
    existing = cursor.fetchone()

    if existing:
        # Update existing entry
        new_total = existing[2] + cost_usd
        new_count = existing[3] + 1

        cursor.execute('''
            UPDATE daily_costs
            SET total_cost_usd = ?, query_count = ?
            WHERE date = ?
        ''', (new_total, new_count, today))
    else:
        # Create new entry
        cursor.execute('''
            INSERT INTO daily_costs (date, total_cost_usd, query_count)
            VALUES (?, ?, ?)
        ''', (today, cost_usd, 1))

    conn.commit()
    conn.close()


def get_best_model_for_topic(topic: str, min_usage: int = 3,
                            min_confidence: float = 0.75) -> Optional[Dict[str, Any]]:
    """
    Get best historical model for a specific topic.

    Args:
        topic: Topic name to query
        min_usage: Minimum number of queries required for reliability
        min_confidence: Minimum average confidence score required

    Returns:
        Dictionary with best model info or None if no strong signal
    """
    init_database()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Query performance data grouped by model
    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) as total_cost
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        ORDER BY usage_count DESC
    ''', (topic,))

    results = cursor.fetchall()
    conn.close()

    if not results:
        return None

    # Find best model meeting thresholds
    for row in results:
        model_used, usage_count, success_rate, avg_confidence, total_cost = row

        if usage_count >= min_usage and avg_confidence >= min_confidence:
            return {
                "model_id": model_used,
                "success_rate": success_rate,
                "usage_count": usage_count,
                "avg_confidence": avg_confidence,
                "total_cost": total_cost,
                "recommendation": "strong" if success_rate > 0.85 else "moderate"
            }

    # Return top model even if below thresholds (weak signal)
    top_row = results[0]
    return {
        "model_id": top_row[0],
        "success_rate": top_row[2],
        "usage_count": top_row[1],
        "avg_confidence": top_row[3],
        "total_cost": top_row[4],
        "recommendation": "weak"
    }


def get_model_for_budget(topic: str, max_cost_usd: float = 5.0,
                        min_success_rate: float = 0.80) -> Optional[Dict[str, Any]]:
    """
    Get best model within budget constraints.

    Args:
        topic: Topic name to query
        max_cost_usd: Maximum acceptable cost per query
        min_success_rate: Minimum acceptable success rate

    Returns:
        Dictionary with budget-optimized model or None
    """
    init_database()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            SUM(cost_usd) / COUNT(*) as avg_cost_per_query
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        HAVING avg_cost_per_query <= ? AND success_rate >= ?
        ORDER BY avg_cost_per_query ASC
        LIMIT 1
    ''', (topic, max_cost_usd, min_success_rate))

    result = cursor.fetchone()
    conn.close()

    if result:
        return {
            "model_id": result[0],
            "success_rate": result[2],
            "avg_cost_per_query": result[3],
            "usage_count": result[1],
            "recommendation": "budget-optimized"
        }

    return None


def get_topic_statistics(topic: str) -> Dict[str, Any]:
    """
    Get comprehensive statistics for a topic.

    Args:
        topic: Topic name to analyze

    Returns:
        Dictionary with topic statistics
    """
    init_database()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Overall stats
    cursor.execute('''
        SELECT
            COUNT(*) as total_queries,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as overall_success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) as total_cost,
            MIN(timestamp) as first_query,
            MAX(timestamp) as last_query
        FROM performance_logs
        WHERE topic = ?
    ''', (topic,))

    overall = cursor.fetchone()

    # By model breakdown
    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) as total_cost
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        ORDER BY usage_count DESC
    ''', (topic,))

    by_model = [
        {
            "model_id": row[0],
            "usage_count": row[1],
            "success_rate": row[2],
            "avg_confidence": row[3],
            "total_cost": row[4]
        }
        for row in cursor.fetchall()
    ]

    conn.close()

    return {
        "topic": topic,
        "total_queries": overall[0] if overall else 0,
        "overall_success_rate": overall[1] if overall else 0,
        "avg_confidence": overall[2] if overall else 0,
        "total_cost": overall[3] if overall else 0,
        "first_query": overall[4],
        "last_query": overall[5],
        "models_tracked": len(by_model),
        "by_model": by_model
    }


def get_daily_cost_report(date: Optional[str] = None) -> Dict[str, Any]:
    """
    Get daily cost report.

    Args:
        date: Date in YYYY-MM-DD format (defaults to today)

    Returns:
        Dictionary with cost report
    """
    if date is None:
        date = datetime.now().strftime("%Y-%m-%d")

    init_database()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT date, total_cost_usd, query_count, by_model, by_topic
        FROM daily_costs
        WHERE date = ?
    ''', (date,))

    row = cursor.fetchone()
    conn.close()

    if row:
        return {
            "date": row[0],
            "total_cost_usd": row[1],
            "query_count": row[2],
            "by_model": json.loads(row[3]) if row[3] else {},
            "by_topic": json.loads(row[4]) if row[4] else {}
        }
    else:
        return {
            "date": date,
            "total_cost_usd": 0,
            "query_count": 0,
            "by_model": {},
            "by_topic": {},
            "message": "No data for this date"
        }


def prune_stale_topics(days_threshold: int = 90) -> Dict[str, Any]:
    """
    Remove topics with no recent activity.

    Args:
        days_threshold: Number of days of inactivity before pruning

    Returns:
        Dictionary with pruning results
    """
    init_database()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cutoff_date = datetime.now().isoformat()[:-7]  # Remove timezone

    # Find stale topics
    cursor.execute('''
        SELECT DISTINCT topic FROM performance_logs
        WHERE timestamp < datetime(?, '-' || ? || ' days')
    ''', (cutoff_date, days_threshold))

    stale_topics = [row[0] for row in cursor.fetchall()]

    # Actually delete them (commented out for safety - uncomment to enable)
    # for topic in stale_topics:
    #     cursor.execute('DELETE FROM performance_logs WHERE topic = ?', (topic,))

    deleted_count = len(stale_topics)  # Would be cursor.rowcount if deleting

    conn.commit()
    conn.close()

    return {
        "threshold_days": days_threshold,
        "stale_topics_found": stale_topics,
        "topics_to_delete": deleted_count,
        "note": "Dry run mode - set to actually delete records"
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("PERFORMANCE LOGGER - Self Test")
    print("=" * 60)

    # Initialize database
    init_database()
    print("✅ Database initialized\n")

    # Log some test queries
    test_data = [
        ("lambda-development", "alibaba-sg/qwen3.5-122b-a10b", True, 500, 1200, 0.0007, 0.92),
        ("lambda-development", "alibaba-sg/qwen3.5-122b-a10b", True, 450, 1000, 0.0006, 0.88),
        ("lambda-development", "anthropic/claude-sonnet-4-6", True, 600, 1500, 0.0045, 0.95),
        ("api-gateway-cors", "google/gemini-2.5-flash", True, 400, 800, 0.0003, 0.85),
    ]

    print("🧪 Logging test queries...")
    for topic, model, success, ti, to, cost, conf in test_data:
        result = log_query_result(topic, model, success, ti, to, cost, conf)
        status = "✅" if result["status"] == "logged" else "❌"
        print(f"{status} Logged: {topic} → {model.split('/')[-1]} (${cost:.4f})")

    print("\n📊 Getting best model for lambda-development:")
    best = get_best_model_for_topic("lambda-development")
    if best:
        print(f"   Model: {best['model_id'].split('/')[-1]}")
        print(f"   Success rate: {best['success_rate']:.0%}")
        print(f"   Usage count: {best['usage_count']}")
        print(f"   Recommendation: {best['recommendation']}")
    else:
        print("   No data available")

    print("\n📈 Topic statistics for lambda-development:")
    stats = get_topic_statistics("lambda-development")
    print(f"   Total queries: {stats['total_queries']}")
    print(f"   Overall success rate: {stats['overall_success_rate']:.0%}")
    print(f"   Total cost: ${stats['total_cost']:.4f}")

    print("\n" + "=" * 60)
    print("Test complete!")
