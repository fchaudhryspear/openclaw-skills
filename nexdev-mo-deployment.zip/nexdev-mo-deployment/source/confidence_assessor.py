#!/usr/bin/env python3
"""
Confidence Assessor Module for Model Orchestrator v2.0

Self-assesses response quality on a 0-1 scale.
Detects positive/negative language patterns, code examples, and uncertainty.
Part of NexDev AI Coding Stack - Phase 1 Implementation
"""

import re
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class ConfidenceResult:
    """Represents a confidence assessment result."""
    score: float
    label: str
    factors: Dict[str, float]
    pre_difficulty: Optional[Dict[str, Any]] = None


# Pattern definitions
POSITIVE_PATTERNS = [
    r'\b(definitely|certainly|absolutely|successfully)\b',
    r'\b(here is the solution|the answer is|this will work)\b',
    r'\b(I have tested|I verified|confirmed)\b',
    r'\b(you can|you should be able to|it will)\b',
    r'\b(proven|tested|working)\b',
]

NEGATIVE_PATTERNS = [
    r'\b(unfortunately|unfortunately|alack)\b',
    r'\b(does not|cannot|unable|impossible)\b',
    r'\b(error|failed|broken|issue with)\b',
    r'\b(problem|trouble|difficulty)\b',
]

UNCERTAINTY_PATTERNS = [
    r'\b(maybe|perhaps|possibly|potentially)\b',
    r'\b(might|could|would|should)\b(?!\s+be\sthe\scase)',
    r'\b(try|attempt|consider|suggest)\b',
    r'\b(probably|likely|probably)\b',
    r"\b(i think|i believe|i'm\sunsure|i don't\sknow)\b",
]

CODE_EXAMPLE_PATTERN = r'```[\w]*\n.*?```'

ERROR_FLAGS = [
    'Error:', 'Exception:', 'Traceback:', 'FAILED:', 'ERROR:'
]

DIFFICULTY_KEYWORDS = {
    'easy': [
        'what is', 'how to', 'time', 'date', 'simple', 'basic',
        'capital of', 'who is', 'where is'
    ],
    'medium': [
        'implement', 'create', 'design', 'build', 'add', 'integrate',
        'configure', 'setup', 'optimize', 'refactor'
    ],
    'complex': [
        'architect', 'design system', 'scalable', 'distributed',
        'microservice', 'event-driven', 'performance optimization',
        'security audit', 'production deployment'
    ]
}


def assess_confidence(response_text: str, user_followup: str = "",
                     has_error: bool = False) -> ConfidenceResult:
    """
    Assess confidence level of a response.

    Args:
        response_text: The model's response text
        user_followup: User's follow-up message (if any)
        has_error: Whether an error occurred

    Returns:
        ConfidenceResult with score and breakdown
    """
    factors = {
        'positive_language': 0.0,
        'code_example': 0.0,
        'negative_language': 0.0,
        'uncertainty': 0.0,
        'error_penalty': 0.0
    }

    text_combined = f"{response_text} {user_followup}".lower()

    # Positive language bonus (+0.02 per pattern)
    for pattern in POSITIVE_PATTERNS:
        if re.search(pattern, text_combined, re.IGNORECASE):
            factors['positive_language'] += 0.02

    # Code example bonus (+0.05)
    if re.search(CODE_EXAMPLE_PATTERN, response_text, re.DOTALL):
        factors['code_example'] = 0.05

    # Negative language penalty (-0.02 per pattern)
    for pattern in NEGATIVE_PATTERNS:
        if re.search(pattern, text_combined, re.IGNORECASE):
            factors['negative_language'] -= 0.02

    # Uncertainty penalty (-0.03 per pattern)
    for pattern in UNCERTAINTY_PATTERNS:
        if re.search(pattern, text_combined, re.IGNORECASE):
            factors['uncertainty'] -= 0.03

    # Severe error penalty (-0.15, capped at -0.40)
    if has_error:
        factors['error_penalty'] = -0.15

    # Check for explicit error flags in response
    for flag in ERROR_FLAGS:
        if flag.lower() in response_text.lower():
            factors['error_penalty'] = max(factors['error_penalty'], -0.25)

    # Calculate base score
    base_score = 0.85  # Start with moderately high confidence

    # Apply adjustments
    total_adjustment = sum(factors.values())
    final_score = max(0.0, min(1.0, base_score + total_adjustment))

    # Map to label
    label = confidence_to_quality_label(final_score)

    return ConfidenceResult(
        score=final_score,
        label=label,
        factors=factors
    )


def self_score_query(query: str) -> Dict[str, Any]:
    """
    Predict query difficulty before answering.

    Args:
        query: User's query text

    Returns:
        Dictionary with predicted difficulty and expected confidence
    """
    query_lower = query.lower()

    for difficulty, keywords in DIFFICULTY_KEYWORDS.items():
        keyword_matches = sum(1 for kw in keywords if kw in query_lower)
        if keyword_matches >= 2:  # At least 2 matching keywords
            return {
                'difficulty': difficulty,
                'expected_confidence': get_expected_confidence(difficulty),
                'complexity_score': get_complexity_score(difficulty),
                'matched_keywords': [kw for kw in keywords if kw in query_lower]
            }

    # Default to medium if no clear signal
    return {
        'difficulty': 'medium',
        'expected_confidence': 0.80,
        'complexity_score': 3,
        'matched_keywords': []
    }


def get_expected_confidence(difficulty: str) -> float:
    """Get expected confidence based on task difficulty."""
    mapping = {
        'easy': 0.90,
        'medium': 0.80,
        'complex': 0.70
    }
    return mapping.get(difficulty, 0.80)


def get_complexity_score(difficulty: str) -> int:
    """Get complexity score (1-5 scale)."""
    mapping = {
        'easy': 1,
        'medium': 3,
        'complex': 5
    }
    return mapping.get(difficulty, 3)


def confidence_to_quality_label(score: float) -> str:
    """
    Convert confidence score to human-readable label.

    Args:
        score: Confidence score (0-1)

    Returns:
        Quality label string
    """
    if score >= 0.95:
        return "Very High"
    elif score >= 0.85:
        return "High"
    elif score >= 0.75:
        return "Moderate"
    elif score >= 0.60:
        return "Low"
    else:
        return "Very Low"


def get_routing_confidence_threshold(difficulty: str) -> float:
    """
    Get confidence threshold for routing decisions based on difficulty.

    Args:
        difficulty: Task difficulty level

    Returns:
        Confidence threshold
    """
    mapping = {
        'easy': 0.70,   # Lower bar for simple queries
        'medium': 0.75, # Standard threshold
        'complex': 0.85 # Higher bar for critical tasks
    }
    return mapping.get(difficulty, 0.75)


def should_escalate(confidence_result: ConfidenceResult,
                   difficulty: str) -> bool:
    """
    Determine if query should be escalated to higher-tier model.

    Args:
        confidence_result: Result from assess_confidence()
        difficulty: Pre-scored difficulty level

    Returns:
        True if escalation recommended
    """
    threshold = get_routing_confidence_threshold(difficulty)

    # Escalate if confidence below threshold for this difficulty
    return confidence_result.score < threshold


def analyze_response_quality(response_text: str) -> Dict[str, Any]:
    """
    Comprehensive analysis of response quality.

    Args:
        response_text: Model's response text

    Returns:
        Dictionary with full quality analysis
    """
    confidence = assess_confidence(response_text)
    has_code = bool(re.search(CODE_EXAMPLE_PATTERN, response_text, re.DOTALL))
    word_count = len(response_text.split())

    # Additional metrics
    sentence_count = len(re.findall(r'[.!?]+', response_text))
    avg_sentence_length = word_count / max(sentence_count, 1)

    # Format quality check
    has_formatting = bool(re.search(r'(\*\*|__|\`|\-|\d+\.)', response_text))

    return {
        'confidence_score': confidence.score,
        'confidence_label': confidence.label,
        'has_code_examples': has_code,
        'word_count': word_count,
        'sentence_count': sentence_count,
        'avg_sentence_length': round(avg_sentence_length, 1),
        'has_formatting': has_formatting,
        'factors_breakdown': confidence.factors
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("CONFIDENCE ASSESSOR - Self Test")
    print("=" * 60)

    test_responses = [
        {
            "name": "Strong answer with code",
            "text": "Here is the solution that will definitely work:\n\n```python\ndef fix_lambda_timeout():\n    return {'status': 'fixed'}\n```\n\nI have tested this and it works perfectly.",
            "expected_label": "High"
        },
        {
            "name": "Uncertain answer",
            "text": "You might want to try checking the documentation... Perhaps you could also look into the configuration files. I think that should help.",
            "expected_label": "Moderate"
        },
        {
            "name": "Error response",
            "text": "Unfortunately, I cannot help with this. Error: Module not found.",
            "expected_label": "Very Low"
        },
        {
            "name": "Simple Q&A",
            "text": "The capital of France is Paris.",
            "expected_label": "High"
        },
    ]

    print("\n🧪 Testing confidence assessment:\n")

    for test in test_responses:
        result = assess_confidence(test["text"])
        status = "✅" if result.label == test["expected_label"] else "⚠️"

        print(f"{status} {test['name']}")
        print(f"   Score: {result.score:.2f}")
        print(f"   Label: {result.label}")
        print(f"   Factors: {result.factors}")
        print()

    print("\n📊 Testing query difficulty prediction:\n")

    test_queries = [
        "What time is it in Paris?",
        "How do I center a div in CSS?",
        "Design a scalable event-driven microservice architecture",
        "Fix Lambda CORS headers"
    ]

    for query in test_queries:
        prediction = self_score_query(query)
        print(f"Query: {query[:50]}...")
        print(f"   Difficulty: {prediction['difficulty']}")
        print(f"   Expected confidence: {prediction['expected_confidence']:.2f}")
        print(f"   Complexity score: {prediction['complexity_score']}")
        print()

    print("=" * 60)
    print("Test complete!")
