#!/usr/bin/env python3
"""
Smart Model Orchestrator v2.0 — Runtime Router
Routes queries to optimal model based on complexity, memory context, and learned performance
"""

import json
import os
from datetime import datetime
from pathlib import Path

MEMORY_ROOT = Path("~/memory").expanduser()
WORKSPACE = Path("/Users/faisalshomemacmini/.openclaw/workspace")
CASCADE_CONFIG = WORKSPACE / "memory/penny_pincher_cascade.json"
PERFORMANCE_LOG = MEMORY_ROOT / "model_performance.json"
ACTIVE_PROJECTS = MEMORY_ROOT / "active_projects.json"

def load_config():
    with open(CASCADE_CONFIG) as f:
        return json.load(f)

def load_performance_log():
    if PERFORMANCE_LOG.exists():
        with open(PERFORMANCE_LOG) as f:
            return json.load(f)
    return {"by_topic": {}, "global_stats": {}}

def save_performance_log(data):
    with open(PERFORMANCE_LOG, 'w') as f:
        json.dump(data, f, indent=2)

def search_clawvault_memory(query):
    """Search ClawVault for matching project/context."""
    results = []
    
    # Check active projects
    if ACTIVE_PROJECTS.exists():
        try:
            with open(ACTIVE_PROJECTS) as f:
                projects = json.load(f)
            # Handle both dict and list formats
            if isinstance(projects, dict):
                for proj_name, proj_data in projects.items():
                    if isinstance(proj_data, dict) and any(keyword.lower() in query.lower() for keyword in proj_data.get("keywords", [])):
                        results.append({
                            "match_found": True,
                            "project_name": proj_name,
                            "last_model_used": proj_data.get("model_used", ""),
                            "confidence": 0.85
                        })
        except (json.JSONDecodeError, AttributeError):
            pass
    
    return results[0] if results else {"match_found": False}

def detect_complexity(query):
    """Detect query type and recommended tier."""
    query_lower = query.lower()
    
    # Coding patterns
    coding_keywords = ["code", "fix", "bug", "debug", "function", "class", "implement", "refactor"]
    if any(kw in query_lower for kw in coding_keywords):
        return {"tier": 2, "primary": "alibaba-sg/qwen-coder", "escalation_chain": ["alibaba-sg/qwen3.5-122b-a10b", "anthropic/claude-sonnet-4-6", "anthropic/claude-opus-4-6"]}
    
    # Architecture patterns
    arch_keywords = ["architecture", "design", "system", "structure", "scalability", "pattern"]
    if any(kw in query_lower for kw in arch_keywords):
        return {"tier": 3, "primary": "alibaba-sg/qwen3.5-122b-a10b", "escalation_chain": ["anthropic/claude-sonnet-4-6", "anthropic/claude-opus-4-6"]}
    
    # Long document patterns
    doc_keywords = ["summarize", "extract", "read this", "analyze", "PDF", "document", "transcript"]
    if any(kw in query_lower for kw in doc_keywords):
        return {"tier": 2, "primary": "google/gemini-2.5-flash", "escalation_chain": ["moonshot/kimi-k2.5", "google/gemini-2.5-pro"]}
    
    # Vision patterns
    vision_keywords = ["image", "photo", "screenshot", "diagram", "chart", "visual"]
    if any(kw in query_lower for kw in vision_keywords):
        return {"tier": 2, "primary": "google/gemini-2.5-flash", "escalation_chain": ["anthropic/claude-sonnet-4-6"]}
    
    # Agent orchestration patterns
    agent_keywords = ["multi-step", "break down", "parallel", "multiple agents", "subagents", "orchestrate"]
    if any(kw in query_lower for kw in agent_keywords):
        return {"tier": 3, "primary": "moonshot/kimi-k2.5", "special_feature": "agent_swarm", "escalation_chain": []}
    
    # Creative patterns
    creative_keywords = ["write", "story", "poem", "creative", "copywriting", "marketing"]
    if any(kw in query_lower for kw in creative_keywords):
        return {"tier": 5, "primary": "anthropic/claude-sonnet-4-6", "escalation_chain": ["anthropic/claude-opus-4-6"]}
    
    # Research patterns
    research_keywords = ["research", "analysis", "compare", "evaluate", "recommend", "best"]
    if any(kw in query_lower for kw in research_keywords):
        return {"tier": 3, "primary": "moonshot/kimi-k2.5", "escalation_chain": ["google/gemini-2.5-pro", "anthropic/claude-opus-4-6"]}
    
    # Default to simple Q&A
    return {"tier": 1, "primary": "alibaba-sg/qwen-turbo", "escalation_chain": ["google/gemini-2.5-flash"]}

def get_best_model_for_topic(topic, performance_log):
    """Get historically best-performing model for a topic."""
    if topic in performance_log.get("by_topic", {}):
        models = performance_log["by_topic"][topic].get("model_scores", {})
        if models:
            # Sort by success_rate weighted by usage_count
            sorted_models = sorted(models.items(), key=lambda x: x[1].get("success_rate", 0), reverse=True)
            return sorted_models[0][0]
    return None

def update_performance_log(topic, model_used, success, confidence_score, cost):
    """Update performance metrics after query completion."""
    log = load_performance_log()
    
    if topic not in log["by_topic"]:
        log["by_topic"][topic] = {"model_scores": {}, "total_queries": 0}
    
    if model_used not in log["by_topic"][topic]["model_scores"]:
        log["by_topic"][topic]["model_scores"][model_used] = {
            "success_count": 0,
            "failure_count": 0,
            "total_cost": 0,
            "avg_confidence": 0,
            "usage_count": 0
        }
    
    stats = log["by_topic"][topic]["model_scores"][model_used]
    stats["usage_count"] += 1
    stats["total_cost"] += cost
    
    if success:
        stats["success_count"] += 1
    else:
        stats["failure_count"] += 1
    
    stats["success_rate"] = stats["success_count"] / (stats["success_count"] + stats["failure_count"])
    stats["avg_confidence"] = (stats["avg_confidence"] * (stats["usage_count"] - 1) + confidence_score) / stats["usage_count"]
    
    log["by_topic"][topic]["total_queries"] += 1
    
    save_performance_log(log)

def route_query(query, topic=None):
    """Main routing function — returns recommended model and escalation chain."""
    config = load_config()
    perf_log = load_performance_log()
    
    # Step 1: Check ClawVault memory
    memory_match = search_clawvault_memory(query)
    if memory_match["match_found"]:
        return {
            "recommended_model": memory_match["last_model_used"],
            "reasoning": "Continuity from previous session",
            "escalation_chain": [],
            "model_attribution": memory_match["last_model_used"].split("/")[-1]
        }
    
    # Step 2: Check topic-based best performer
    if topic:
        best_model = get_best_model_for_topic(topic, perf_log)
        if best_model:
            return {
                "recommended_model": best_model,
                "reasoning": f"Historically best for '{topic}' ({perf_log['by_topic'][topic]['model_scores'][best_model]['success_rate']:.1%} success rate)",
                "escalation_chain": [],
                "model_attribution": best_model.split("/")[-1]
            }
    
    # Step 3: Complexity detection
    complexity = detect_complexity(query)
    return {
        "recommended_model": complexity["primary"],
        "reasoning": f"Detected {complexity['tier']} complexity task",
        "escalation_chain": complexity.get("escalation_chain", []),
        "special_feature": complexity.get("special_feature"),
        "model_attribution": complexity["primary"].split("/")[-1]
    }

def format_response_with_attribution(response_text, model_alias):
    """Append model attribution to response."""
    return f"{response_text}\n\n— {model_alias}"

# Example usage when integrated into OpenClaw:
if __name__ == "__main__":
    test_query = "Can you help me refactor this AWS Lambda function to handle CORS better?"
    result = route_query(test_query, topic="lambda-development")
    
    print(f"Query: {test_query}")
    print(f"Recommended: {result['recommended_model']}")
    print(f"Reasoning: {result['reasoning']}")
    print(f"Escalation chain: {result['escalation_chain']}")
    print(f"Attribution tag: - {result['model_attribution']}")
