#!/usr/bin/env python3
"""
Session-Aware Router Module for Model Orchestrator v2.0

Maintains model consistency across related conversation turns.
Prevents unnecessary model switching during topic discussions.
Part of NexDev AI Coding Stack - Phase 4 Implementation
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

# Database path
DB_PATH = Path.home() / ".openclaw/workspace/memory/project_graph.db"


@dataclass
class SessionState:
    """Represents current session state."""
    id: int
    current_topic: str
    current_model: str
    started_at: str
    last_updated: str


def get_session_state() -> Optional[SessionState]:
    """
    Get current session state from database.

    Returns:
        SessionState object or None if no state exists
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    try:
        cursor.execute('SELECT * FROM session_state WHERE id = 1')
        row = cursor.fetchone()

        if row:
            return SessionState(
                id=row[0],
                current_topic=row[1],
                current_model=row[2],
                started_at=row[3],
                last_updated=row[4]
            )
        else:
            # Initialize default state
            _initialize_default_session()
            return get_session_state()

    finally:
        conn.close()


def _initialize_default_session():
    """Initialize default session state."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        INSERT OR IGNORE INTO session_state (id, current_topic, current_model, started_at)
        VALUES (1, 'general', 'google/gemini-2.0-flash-lite', ?)
    ''', (datetime.now().isoformat(),))

    conn.commit()
    conn.close()


def start_session(topic: str, model: str) -> Dict[str, Any]:
    """
    Start or resume a session with given topic and model.

    Args:
        topic: Topic name (e.g., "lambda-development")
        model: Model identifier (e.g., "alibaba-sg/qwen3.5-122b-a10b")

    Returns:
        Dictionary with session info
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Check existing session
    cursor.execute('SELECT current_topic FROM session_state WHERE id = 1')
    existing = cursor.fetchone()

    is_new_session = False
    topic_switched = False

    if not existing:
        # Initialize new session
        cursor.execute('''
            INSERT INTO session_state (id, current_topic, current_model, started_at, last_updated)
            VALUES (1, ?, ?, ?, ?)
        ''', (topic, model, datetime.now().isoformat(), datetime.now().isoformat()))
        is_new_session = True
    else:
        old_topic = existing[0]
        if old_topic != topic:
            topic_switched = True

        # Update session
        cursor.execute('''
            UPDATE session_state
            SET current_topic = ?, current_model = ?, last_updated = ?
            WHERE id = 1
        ''', (topic, model, datetime.now().isoformat()))

    conn.commit()
    conn.close()

    return {
        "status": "started",
        "is_new_session": is_new_session,
        "topic_switched": topic_switched,
        "new_topic": topic,
        "new_model": model
    }


def update_session(topic: str, model: str, force_switch: bool = False) -> Dict[str, Any]:
    """
    Update session state after a query completes.

    Args:
        topic: Detected topic for this query
        model: Model used for this query
        force_switch: Force topic switch even if within threshold

    Returns:
        Dictionary with update result
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Get current state
    cursor.execute('''
        SELECT current_topic, current_model, started_at, last_updated
        FROM session_state WHERE id = 1
    ''')
    row = cursor.fetchone()

    if not row:
        conn.close()
        return start_session(topic, model)

    current_topic = row[0]
    current_model = row[1]
    started_at = datetime.fromisoformat(row[2])
    last_updated = datetime.fromisoformat(row[3])

    # Decide whether to switch topics
    should_switch = _should_allow_topic_switch(
        current_topic, topic,
        started_at, last_updated,
        force_switch
    )

    if should_switch or current_model != model:
        # Update state
        cursor.execute('''
            UPDATE session_state
            SET current_topic = ?, current_model = ?, last_updated = ?
            WHERE id = 1
        ''', (topic, model, datetime.now().isoformat()))
        conn.commit()

        conn.close()

        return {
            "status": "updated",
            "topic_switched": should_switch and current_topic != topic,
            "model_changed": current_model != model,
            "old_topic": current_topic,
            "new_topic": topic,
            "old_model": current_model,
            "new_model": model
        }

    conn.close()

    return {
        "status": "stable",
        "topic": topic,
        "model": model,
        "unchanged": True
    }


def _should_allow_topic_switch(
    old_topic: str,
    new_topic: str,
    started_at: datetime,
    last_updated: datetime,
    force_switch: bool
) -> bool:
    """
    Determine if topic switch should be allowed based on momentum.

    Args:
        old_topic: Previously active topic
        new_topic: Proposed new topic
        started_at: Session start time
        last_updated: Last state update time
        force_switch: Force override

    Returns:
        True if switch should be allowed
    """
    if force_switch:
        return True

    if old_topic == new_topic:
        return False

    # Allow switch if session is short (< 5 minutes)
    if datetime.now() - started_at < timedelta(minutes=5):
        return True

    # Allow switch if enough time has passed since last activity (> 30 minutes)
    if datetime.now() - last_updated > timedelta(minutes=30):
        return True

    # Check for natural topic transition patterns
    # Same technology stack? Keep going
    tech_groups = {
        "aws": ["lambda-development", "api-gateway-cors", "cognito-auth", "infrastructure-as-code"],
        "database": ["database-migrations", "snowflake-integration"],
        "frontend": ["web-development"],
        "testing": ["testing-setup"]
    }

    for group_topics in tech_groups.values():
        if old_topic in group_topics and new_topic in group_topics:
            return False  # Keep same model within tech stack

    # Default: allow switch for different topics
    return True


def get_session_topic() -> Optional[str]:
    """Get current sticky topic."""
    state = get_session_state()
    return state.current_topic if state else None


def get_current_model() -> Optional[str]:
    """Get currently active model."""
    state = get_session_state()
    return state.current_model if state else None


def get_session_summary() -> Dict[str, Any]:
    """
    Get summary of session activity.

    Returns:
        Dictionary with session statistics
    """
    state = get_session_state()

    if not state:
        return {"error": "No session found"}

    # Calculate duration
    started_at = datetime.fromisoformat(state.started_at)
    now = datetime.now()
    duration = now - started_at

    # Query topic history from performance logs
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT topic, COUNT(*) as count
        FROM performance_logs
        WHERE timestamp >= ?
        GROUP BY topic
        ORDER BY count DESC
    ''', (state.started_at,))

    topic_breakdown = {row[0]: row[1] for row in cursor.fetchall()}
    total_queries = sum(topic_breakdown.values())

    # Find primary topic
    primary_topic = max(topic_breakdown.items(), key=lambda x: x[1])[0] if topic_breakdown else None

    conn.close()

    return {
        "current_topic": state.current_topic,
        "current_model": state.current_model,
        "session_start": state.started_at,
        "last_update": state.last_updated,
        "duration_minutes": int(duration.total_seconds() / 60),
        "total_queries": total_queries,
        "topics_discussed": len(topic_breakdown),
        "primary_topic": primary_topic,
        "topic_breakdown": topic_breakdown
    }


def reset_session(confirm: bool = False) -> Dict[str, Any]:
    """
    Reset session state to defaults.

    Args:
        confirm: Skip confirmation prompt

    Returns:
        Dictionary with reset result
    """
    if not confirm:
        response = input("Reset session state? (yes/no): ")
        if response.lower() != "yes":
            return {"status": "cancelled"}

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        UPDATE session_state
        SET current_topic = 'general',
            current_model = 'google/gemini-2.0-flash-lite',
            started_at = ?,
            last_updated = ?
        WHERE id = 1
    ''', (datetime.now().isoformat(), datetime.now().isoformat()))

    conn.commit()
    conn.close()

    return {
        "status": "reset",
        "current_topic": "general",
        "current_model": "google/gemini-2.0-flash-lite"
    }


def track_topic_momentum(topic: str) -> Dict[str, Any]:
    """
    Track how long a topic has been active consecutively.

    Args:
        topic: Topic to track

    Returns:
        Dictionary with momentum metrics
    """
    state = get_session_state()

    if not state:
        return {"error": "No session found"}

    if state.current_topic != topic:
        return {
            "topic": topic,
            "active": False,
            "current_active_topic": state.current_topic
        }

    # Calculate how long this topic has been dominant
    started_at = datetime.fromisoformat(state.started_at)
    now = datetime.now()
    consecutive_time = now - started_at

    # Count recent queries for this topic
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT COUNT(*)
        FROM performance_logs
        WHERE topic = ? AND timestamp >= ?
    ''', (topic, state.started_at))

    count = cursor.fetchone()[0]
    conn.close()

    return {
        "topic": topic,
        "active": True,
        "consecutive_minutes": int(consecutive_time.total_seconds() / 60),
        "query_count": count,
        "momentum": "strong" if count > 5 else "moderate" if count > 2 else "weak"
    }


def suggest_model_switch(query: str) -> Dict[str, Any]:
    """
    Suggest whether to switch models based on new query topic.

    Args:
        query: New incoming query

    Returns:
        Dictionary with switch recommendation
    """
    from topic_extractor import extract_topic

    # Get current state
    state = get_session_state()

    if not state:
        return {
            "recommendation": "start_session",
            "message": "No active session"
        }

    # Extract topic from new query
    matches = extract_topic(query)

    if not matches:
        return {
            "recommendation": "keep",
            "current_topic": state.current_topic,
            "current_model": state.current_model,
            "message": "No topic detected, keep current model"
        }

    new_topic = matches[0].topic

    # Check if we should switch
    if new_topic == state.current_topic:
        return {
            "recommendation": "keep",
            "current_topic": state.current_topic,
            "current_model": state.current_model,
            "reason": "Same topic, maintain consistency"
        }

    # Different topic - check if switch makes sense
    if _should_allow_topic_switch(
        state.current_topic, new_topic,
        datetime.fromisoformat(state.started_at),
        datetime.fromisoformat(state.last_updated),
        force_switch=False
    ):
        # Load preferred model for new topic
        with open(Path.home() / ".openclaw/workspace/memory/routing_topics.json") as f:
            config = json.load(f)

        new_topic_config = config.get("topics", {}).get(new_topic, {})
        preferred_models = new_topic_config.get("preferred_models", [])

        recommended_model = preferred_models[0] if preferred_models else state.current_model

        return {
            "recommendation": "switch",
            "current_topic": state.current_topic,
            "current_model": state.current_model,
            "new_topic": new_topic,
            "recommended_model": recommended_model,
            "reason": f"Topic changed to {new_topic}"
        }

    return {
        "recommendation": "keep",
        "current_topic": state.current_topic,
        "current_model": state.current_model,
        "detected_topic": new_topic,
        "reason": "Topic switch blocked by momentum rules"
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("SESSION AWARE ROUTER - Self Test")
    print("=" * 60)

    print("\n📊 Current Session State:")
    summary = get_session_summary()
    print(f"  Current topic: {summary.get('current_topic', 'N/A')}")
    print(f"  Current model: {summary.get('current_model', 'N/A')}")
    print(f"  Duration: {summary.get('duration_minutes', 0)} minutes")
    print(f"  Queries: {summary.get('total_queries', 0)}")
    print()

    print("🧪 Testing session updates:\n")

    # Simulate starting a new session
    result = start_session("lambda-development", "alibaba-sg/qwen3.5-122b-a10b")
    print(f"Start session: {result['status']}")
    print(f"  New topic: {result['new_topic']}")
    print()

    # Update within same topic
    result = update_session("lambda-development", "alibaba-sg/qwen3.5-122b-a10b")
    print(f"Update same topic: {result['status']}")
    print(f"  Unchanged: {result.get('unchanged', False)}")
    print()

    # Switch to different topic
    result = update_session("api-gateway-cors", "google/gemini-2.5-flash")
    print(f"Switch topic: {result['status']}")
    print(f"  Topic switched: {result.get('topic_switched', False)}")
    print(f"  Old topic: {result.get('old_topic')}")
    print(f"  New topic: {result.get('new_topic')}")
    print()

    print("✅ Session tracking complete!")
