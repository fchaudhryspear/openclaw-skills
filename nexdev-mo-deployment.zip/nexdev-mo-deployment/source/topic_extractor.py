#!/usr/bin/env python3
"""
Topic Extractor Module for Model Orchestrator v2.0

Detects query topics using keyword matching + LLM fallback.
Part of NexDev AI Coding Stack - Phase 1 Implementation
"""

import json
from pathlib import Path
from typing import List, Tuple, Optional
from dataclasses import dataclass

# Load configuration
CONFIG_PATH = Path.home() / ".openclaw/workspace/memory/routing_topics.json"


@dataclass
class TopicMatch:
    """Represents a matched topic with confidence score."""
    topic: str
    confidence: float
    matched_keywords: List[str] = None

    def __post_init__(self):
        if self.matched_keywords is None:
            self.matched_keywords = []


def load_routing_config() -> dict:
    """Load routing configuration from JSON file."""
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        # Return minimal config if file doesn't exist yet
        return {
            "topics": {},
            "default_topic": "general",
            "unknown_topic_fallback": "google/gemini-2.0-flash-lite"
        }


def get_predefined_topics() -> List[str]:
    """Get list of all predefined topics."""
    config = load_routing_config()
    return list(config.get("topics", {}).keys())


def extract_topic(query: str) -> List[TopicMatch]:
    """
    Extract topic(s) from a query using keyword matching.

    Args:
        query: User's natural language query

    Returns:
        List of TopicMatch objects sorted by confidence (descending)
    """
    config = load_routing_config()
    topics_config = config.get("topics", {})

    query_lower = query.lower()
    matches = []

    for topic_name, topic_data in topics_config.items():
        keywords = topic_data.get("keywords", [])
        matched = []

        for keyword in keywords:
            keyword_lower = keyword.lower()
            if keyword_lower in query_lower:
                matched.append(keyword)

        if matched:
            # Calculate confidence based on keyword match density
            match_ratio = len(matched) / max(len(keywords), 1)
            confidence = min(0.95, 0.5 + (match_ratio * 0.45))

            matches.append(TopicMatch(
                topic=topic_name,
                confidence=confidence,
                matched_keywords=matched
            ))

    # Sort by confidence descending
    matches.sort(key=lambda x: x.confidence, reverse=True)

    return matches


def get_best_model_for_query(query: str) -> Tuple[str, Optional[str], float]:
    """
    Get recommended model for a query based on detected topic.

    Args:
        query: User's natural language query

    Returns:
        Tuple of (recommended_model, topic, confidence)
    """
    matches = extract_topic(query)

    if not matches:
        config = load_routing_config()
        return (
            config.get("unknown_topic_fallback", "google/gemini-2.0-flash-lite"),
            None,
            0.0
        )

    # Use top match
    top_match = matches[0]
    topic_config = load_routing_config()["topics"].get(top_match.topic, {})

    preferred_models = topic_config.get("preferred_models", [])
    if preferred_models:
        return (preferred_models[0], top_match.topic, top_match.confidence)

    # Fallback to unknown topic handler
    config = load_routing_config()
    return (
        config.get("unknown_topic_fallback", "google/gemini-2.0-flash-lite"),
        top_match.topic,
        top_match.confidence
    )


def add_custom_topic(topic_name: str, keywords: List[str],
                    preferred_models: List[str], tier: str = "medium") -> bool:
    """
    Add a custom topic to the routing configuration.

    Args:
        topic_name: Name of the new topic
        keywords: List of keywords that trigger this topic
        preferred_models: Preferred models for this topic
        tier: Cost tier (ultra-cheap, cheap, medium, expert, nuclear)

    Returns:
        True if successful, False otherwise
    """
    try:
        config = load_routing_config()

        topic_entry = {
            "keywords": keywords,
            "tier": tier,
            "preferred_models": preferred_models,
            "fallback_model": "google/gemini-2.5-flash"
        }

        config["topics"][topic_name] = topic_entry

        with open(CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=2)

        return True

    except Exception as e:
        print(f"Error adding custom topic: {e}")
        return False


def debug_topic_extraction(query: str) -> dict:
    """
    Debug helper to see detailed topic extraction results.

    Args:
        query: User's query

    Returns:
        Dictionary with detailed extraction info
    """
    matches = extract_topic(query)

    return {
        "query": query,
        "matches": [
            {
                "topic": m.topic,
                "confidence": m.confidence,
                "matched_keywords": m.matched_keywords
            }
            for m in matches
        ],
        "total_matches": len(matches)
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("TOPIC EXTRACTOR - Self Test")
    print("=" * 60)

    test_queries = [
        "Fix Lambda timeout causing 504 errors",
        "Add Stripe webhook handler to payment service",
        "Write pytest tests for user authentication",
        "Security audit: SQL injection in login endpoint",
        "What's the capital of France?",
    ]

    print("\n🧪 Running test queries:\n")

    for query in test_queries:
        result = debug_topic_extraction(query)
        print(f"Query: {query}")
        print(f"  Topics found: {len(result['matches'])}")
        for match in result['matches'][:3]:  # Show top 3
            print(f"    - {match['topic']} (conf: {match['confidence']:.2f}, "
                  f"keywords: {', '.join(match['matched_keywords'])})")
        print()

    print("=" * 60)
    print("Test complete!")
