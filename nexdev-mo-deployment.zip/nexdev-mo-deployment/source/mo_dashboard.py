#!/usr/bin/env python3
"""
MO Dashboard CLI for Model Orchestrator v2.0

Visual performance monitoring and maintenance tools.
Provides stats, costs, pruning, and reset capabilities.
Part of NexDev AI Coding Stack - Phase 1 Implementation
"""

import sqlite3
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List

# Paths
DB_PATH = Path.home() / ".openclaw/workspace/memory/project_graph.db"
PRICING_PATH = Path.home() / ".openclaw/workspace/memory/model_pricing.json"


def ensure_database():
    """Ensure database exists, warn if not."""
    if not DB_PATH.exists():
        print("❌ Database not found!")
        print(f"   Run: python3 ~/.openclaw/workspace/memory/init_db.py")
        print("   Or use 'mo-stats init' to create it.")
        return False
    return True


def get_success_bar(success_rate: float, width: int = 40) -> str:
    """Generate colored ASCII bar for success rate display."""
    filled = int(width * success_rate)

    # Use Unicode block characters for smooth gradient
    bars = ['▏', '▎', '▍', '▌', '▋', '▊', '▉', '█']

    bar_str = '█' * filled + '░' * (width - filled)

    # Add color codes based on success rate
    if success_rate >= 0.9:
        color_start = '\033[92m'  # Green
    elif success_rate >= 0.7:
        color_start = '\033[93m'  # Yellow
    else:
        color_start = '\033[91m'  # Red

    color_end = '\033[0m'

    return f"{color_start}{bar_str}{color_end}"


def show_all_topics() -> None:
    """Display all tracked topics with performance overview."""
    if not ensure_database():
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Get all topics
    cursor.execute('''
        SELECT
            topic,
            COUNT(*) as total_queries,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) as total_cost,
            MAX(timestamp) as last_query
        FROM performance_logs
        GROUP BY topic
        ORDER BY total_queries DESC
    ''')

    topics = cursor.fetchall()
    conn.close()

    if not topics:
        print("\n📊 No topics tracked yet.\n")
        print("   Start using the system to collect data!")
        print("   Each query will be automatically logged.")
        return

    print("\n" + "=" * 80)
    print("📊 MODEL ORCHESTRATOR - TOPICS OVERVIEW")
    print("=" * 80)
    print(f"\n{len(topics)} topics tracked\n")

    print(f"{'Topic':<35} {'Queries':>8} {'Success':>10} {'Confidence':>12} {'Cost':>12}")
    print("-" * 80)

    for topic, queries, success, confidence, cost, last in topics:
        short_topic = topic[:33] + ".." if len(topic) > 35 else topic
        bar = get_success_bar(success if success else 0)

        print(f"{short_topic:<35} {queries:>8} {bar} {success:>6.0%} {confidence:>10.2f} ${cost:>10.4f}")

    print("-" * 80)
    print(f"{'TOTAL':<35} {sum(t[1] for t in topics):>8} {'N/A':>10} "
          f"{sum(sum(1 for _ in range(1)) for _ in topics):>12} ${sum(t[4] for t in topics):>10.4f}\n")


def show_topic_details(topic: str) -> None:
    """Show detailed analysis for a specific topic."""
    if not ensure_database():
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Check if topic exists
    cursor.execute('SELECT COUNT(*) FROM performance_logs WHERE topic = ?', (topic,))
    if cursor.fetchone()[0] == 0:
        print(f"\n❌ No data found for topic: '{topic}'\n")
        print("Available topics:")
        cursor.execute('SELECT DISTINCT topic FROM performance_logs ORDER BY topic')
        for row in cursor.fetchall():
            print(f"  - {row[0]}")
        conn.close()
        return

    # Topic overview
    cursor.execute('''
        SELECT
            COUNT(*) as total_queries,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) as total_cost,
            MIN(timestamp) as first_query,
            MAX(timestamp) as last_query
        FROM performance_logs
        WHERE topic = ?
    ''', (topic,))

    overview = cursor.fetchone()

    # By model breakdown
    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as usage_count,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            AVG(confidence_score) as avg_confidence,
            SUM(cost_usd) as total_cost,
            SUM(tokens_input) as total_tokens_in,
            SUM(tokens_output) as total_tokens_out
        FROM performance_logs
        WHERE topic = ?
        GROUP BY model_used
        ORDER BY usage_count DESC
    ''', (topic,))

    models = cursor.fetchall()
    conn.close()

    # Calculate efficiency scores
    model_data = []
    for m in models:
        model_id, usage, success, conf, cost, tokens_in, tokens_out = m
        avg_cost = cost / usage if usage > 0 else 0
        efficiency = success / avg_cost if avg_cost > 0 else success * 10000
        model_data.append({
            'model_id': model_id,
            'usage': usage,
            'success': success,
            'confidence': conf,
            'cost': cost,
            'avg_cost': avg_cost,
            'efficiency': efficiency,
            'tokens_in': tokens_in,
            'tokens_out': tokens_out
        })

    # Print detailed report
    print("\n" + "=" * 80)
    print(f"📊 TOPIC DETAILS: {topic}")
    print("=" * 80)

    print(f"\nOverview:")
    print(f"  Total queries:     {overview[0]}")
    print(f"  Success rate:      {overview[1]:.0%}")
    print(f"  Avg confidence:    {overview[2]:.2f}")
    print(f"  Total cost:        ${overview[3]:.4f}")
    print(f"  First query:       {overview[4][:19] if overview[4] else 'N/A'}")
    print(f"  Last query:        {overview[5][:19] if overview[5] else 'N/A'}")

    print(f"\nModels used (ranked by efficiency):\n")
    print(f"{'Model':<40} {'Used':>6} {'✓':>8} {'Conf':>8} {'Cost/Query':>12} {'Efficiency':>12}")
    print("-" * 88)

    for m in sorted(model_data, key=lambda x: x['efficiency'], reverse=True):
        model_name = m['model_id'].split('/')[-1][:38]
        bar = get_success_bar(m['success'])
        print(f"{model_name:<40} {m['usage']:>6} {bar} {m['success']:>6.0%} "
              f"${m['avg_cost']:>10.6f} {m['efficiency']:>10.1f}")

    print()


def show_model_usage() -> None:
    """Show usage distribution across all models."""
    if not ensure_database():
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as total_queries,
            AVG(CASE WHEN success THEN 1 ELSE 0 END) as success_rate,
            SUM(cost_usd) as total_cost
        FROM performance_logs
        GROUP BY model_used
        ORDER BY total_queries DESC
    ''')

    models = cursor.fetchall()
    conn.close()

    if not models:
        print("\n📊 No model usage data yet.\n")
        return

    total_queries = sum(m[1] for m in models)

    print("\n" + "=" * 80)
    print("📊 MODEL USAGE DISTRIBUTION")
    print("=" * 80)

    print(f"\n{'Model':<45} {'Queries':>10} {'Share':>10} {'Success':>10} {'Cost':>12}")
    print("-" * 88)

    for model, queries, success, cost in models:
        short_model = model.split('/')[-1][:43]
        share = (queries / total_queries) * 100 if total_queries > 0 else 0
        bar_width = int(share / 2)  # Max 50 chars wide
        bar = '█' * bar_width + '░' * (50 - bar_width)

        print(f"{short_model:<45} {queries:>10} {bar} {share:>6.1f}% {success:>8.0%} ${cost:>10.4f}")

    print("-" * 88)
    print(f"{'TOTAL':<45} {total_queries:>10} {'100%':>10} N/A ${sum(m[3] for m in models):>10.4f}\n")


def show_costs() -> None:
    """Show cost breakdown by topic and model."""
    if not ensure_database():
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Overall daily costs
    cursor.execute('''
        SELECT date, total_cost_usd, query_count
        FROM daily_costs
        ORDER BY date DESC
        LIMIT 7
    ''')

    daily = cursor.fetchall()

    # By topic
    cursor.execute('''
        SELECT
            topic,
            COUNT(*) as queries,
            SUM(cost_usd) as total_cost,
            AVG(cost_usd) as avg_cost
        FROM performance_logs
        GROUP BY topic
        ORDER BY total_cost DESC
    ''')

    by_topic = cursor.fetchall()

    # By model
    cursor.execute('''
        SELECT
            model_used,
            COUNT(*) as queries,
            SUM(cost_usd) as total_cost,
            AVG(cost_usd) as avg_cost
        FROM performance_logs
        GROUP BY model_used
        ORDER BY total_cost DESC
    ''')

    by_model = cursor.fetchall()

    conn.close()

    print("\n" + "=" * 80)
    print("💰 COST BREAKDOWN")
    print("=" * 80)

    # Daily costs (last 7 days)
    print("\n📅 Last 7 Days:")
    print(f"{'Date':<15} {'Cost':>12} {'Queries':>10}")
    print("-" * 40)

    for date, cost, queries in daily:
        print(f"{date:<15} ${cost:>10.4f} {queries:>10}")

    if not daily:
        print("  No cost data yet")

    # By topic
    print("\n📊 By Topic:")
    print(f"{'Topic':<35} {'Total Cost':>12} {'Queries':>10} {'Avg/Query':>12}")
    print("-" * 72)

    for topic, queries, total, avg in by_topic:
        short_topic = topic[:33] + ".." if len(topic) > 35 else topic
        print(f"{short_topic:<35} ${total:>10.4f} {queries:>10} ${avg:>10.6f}")

    if not by_topic:
        print("  No topic data yet")

    # By model
    print("\n🤖 By Model:")
    print(f"{'Model':<40} {'Total Cost':>12} {'Queries':>10} {'Avg/Query':>12}")
    print("-" * 76)

    for model, queries, total, avg in by_model:
        short_model = model.split('/')[-1][:38]
        print(f"{short_model:<40} ${total:>10.4f} {queries:>10} ${avg:>10.6f}")

    if not by_model:
        print("  No model data yet")

    # Summary
    total_spent = sum(m[2] for m in by_topic) if by_topic else 0
    total_queries = sum(m[1] for m in by_topic) if by_topic else 0

    print("\n" + "-" * 80)
    print(f"TOTAL SPENT: ${total_spent:.4f} ({total_queries} queries)")
    if total_queries > 0:
        print(f"AVG COST/QUERY: ${total_spent/total_queries:.6f}")
    print()


def prune_stale_topics(days: int = 90, dry_run: bool = True) -> None:
    """Remove topics with no activity for specified days."""
    if not ensure_database():
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cutoff_date = (datetime.now() - __import__('datetime').timedelta(days=days)).isoformat()[:19]

    # Find stale topics
    cursor.execute('''
        SELECT topic, MAX(timestamp) as last_activity, COUNT(*) as query_count
        FROM performance_logs
        GROUP BY topic
        HAVING last_activity < ?
        ORDER BY last_activity ASC
    ''', (cutoff_date,))

    stale_topics = cursor.fetchall()

    if dry_run:
        if stale_topics:
            print(f"\n🧹 DRY RUN: Would prune topics inactive for {days}+ days:\n")
            for topic, last, count in stale_topics:
                print(f"  - {topic} (last: {last[:19]}, queries: {count})")
            print(f"\nTotal: {len(stale_topics)} topics would be removed")
            print("\nRun without --dry-run to actually delete these records.")
        else:
            print(f"\n✅ No topics inactive for {days}+ days. Nothing to prune.")
    else:
        deleted = 0
        for topic, _, _ in stale_topics:
            cursor.execute('DELETE FROM performance_logs WHERE topic = ?', (topic,))
            deleted += cursor.rowcount

        conn.commit()
        print(f"\n🗑️  Pruned {len(stale_topics)} topics ({deleted} records removed)\n")

    conn.close()


def reset_database(confirm: bool = False) -> None:
    """Wipe all learning data (with confirmation)."""
    if not confirm:
        print("⚠️  WARNING: This will DELETE all learning data!")
        print("   This cannot be undone.\n")
        response = input("Type 'RESET ALL DATA' to confirm: ")
        if response != "RESET ALL DATA":
            print("❌ Cancelled. No data was deleted.")
            return

    if not ensure_database():
        return

    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Count records before deletion
        cursor.execute('SELECT COUNT(*) FROM performance_logs')
        count = cursor.fetchone()[0]

        # Clear tables
        cursor.execute('DELETE FROM performance_logs')
        cursor.execute('DELETE FROM daily_costs')

        conn.commit()
        conn.close()

        print(f"\n✅ All data cleared ({count} records deleted)\n")
        print("   The database structure is intact, ready for new data.")

    except Exception as e:
        print(f"\n❌ Error clearing data: {e}")


def show_help() -> None:
    """Display help information."""
    print("""
📊 MODEL ORCHESTRATOR DASHBOARD HELP

Usage: mo-stats [command] [options]

Commands:
  (no command)           Show all topics overview
  --topic <name>         Detailed analysis for specific topic
  --models               Model usage distribution
  --costs                Cost breakdown by topic/model
  --prune [days]         Remove stale topics (>N days, default: 90)
                         Add --dry-run flag to preview without deleting
  --reset                Wipe all learning data (requires confirmation)
  --help, -h             Show this help message

Examples:
  mo-stats                        # Overview of all topics
  mo-stats --topic lambda-dev     # Details for specific topic
  mo-stats --costs                # See spending breakdown
  mo-stats --prune 90 --dry-run   # Preview stale topics
  mo-stats --prune 90             # Actually delete old topics

Environment:
  DB_PATH: ~/.openclaw/workspace/memory/project_graph.db

""")


def main():
    """Main entry point for mo-stats CLI."""
    args = sys.argv[1:]

    if not args or '--help' in args or '-h' in args:
        if args:
            show_help()
        else:
            show_all_topics()
        return

    # Parse arguments
    i = 0
    while i < len(args):
        arg = args[i]

        if arg == '--topic' and i + 1 < len(args):
            show_topic_details(args[i + 1])
            return
        elif arg == '--models':
            show_model_usage()
            return
        elif arg == '--costs':
            show_costs()
            return
        elif arg == '--prune':
            days = 90
            dry_run = True

            # Check for number argument
            if i + 1 < len(args) and args[i + 1].isdigit():
                days = int(args[i + 1])
                i += 1

            # Check for dry-run flag
            if '--dry-run' in args:
                dry_run = True

            prune_stale_topics(days, dry_run)
            return
        elif arg == '--reset':
            reset_database(confirm=False)
            return

        i += 1

    # Default: show all topics
    show_all_topics()


if __name__ == "__main__":
    main()
