#!/usr/bin/env python3
"""Demo of Model Router with Attribution and Learning"""

import sys
sys.path.insert(0, '/Users/faisalshomemacmini/.openclaw/workspace/memory')

from model_router import route_query, format_response_with_attribution, update_performance_log

test_queries = [
    ("What's 2+2?", "simple-facts"),
    ("Refactor this Lambda to handle CORS", "lambda-development"),
    ("Design an architecture for multi-tenant SaaS", "system-architecture"),
    ("Summarize this PDF about travel credit cards", "travel-research"),
    ["Create a marketing campaign email", "creative-writing"],
    ("Debug this React component", "web-development"),
    ("Break down my Madrid trip planning into parallel tasks", "travel-planning"),
]

print("=" * 80)
print("MODEL ROUTER DEMO — WITH ATTRIBUTION & LEARNING")
print("=" * 80)
print()

for i, (query, topic) in enumerate(test_queries, 1):
    result = route_query(query, topic=topic)
    
    # Simulate response and confidence score
    simulated_confidence = 0.92 if result["recommended_model"] == "alibaba-sg/qwen-turbo" else 0.78
    
    print(f"{i}. Query: '{query[:50]}...'")
    print(f"   Topic: {topic}")
    print(f"   → Recommended: {result['model_attribution']} ({result['recommended_model']})")
    print(f"   → Reasoning: {result['reasoning']}")
    if result.get("escalation_chain"):
        print(f"   → Escalation chain: {[m.split('/')[-1] for m in result['escalation_chain']]}")
    if result.get("special_feature"):
        print(f"   → Special feature: {result['special_feature']}")
    print(f"   Response would be tagged: — {result['model_attribution']}")
    print()

# Demonstrate performance learning
print("=" * 80)
print("PERFORMANCE LEARNING SIMULATION")
print("=" * 80)
print()

sample_topics = ["lambda-development", "travel-research", "system-architecture"]
sample_models = ["anthropic/claude-sonnet-4-6", "moonshot/kimi-k2.5", "alibaba-sg/qwen3.5-122b-a10b"]

for topic, model in zip(sample_topics, sample_models):
    success = True
    confidence = 0.89
    cost = 0.003  # Simulated cost
    
    update_performance_log(topic, model, success, confidence, cost)
    print(f"Logged: {topic} → {model.split('/')[-1]} | Success={success} | Confidence={confidence:.2f}")

print()
print("Performance data saved to ~/memory/model_performance.json")
print("Router will now learn which models perform best per topic!")
