#!/usr/bin/env python3
"""
Multi-Objective Optimization Module for Model Orchestrator v2.0

Balances cost, speed, and quality simultaneously using weighted scoring + Pareto efficiency.
Implements strategy-based model selection (cost-first, speed-first, quality-first, balanced).
Part of NexDev AI Coding Stack - Phase 5 Implementation
"""

import json
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum

# Paths
PRICING_PATH = Path.home() / ".openclaw/workspace/memory/model_pricing.json"
CONFIG_PATH = Path.home() / ".openclaw/workspace/memory/.mo_config.json"


class Strategy(Enum):
    """Optimization strategies."""
    COST_FIRST = "cost-first"
    SPEED_FIRST = "speed-first"
    QUALITY_FIRST = "quality-first"
    BALANCED = "balanced"


@dataclass
class ModelProfile:
    """Represents a model's profile across objectives."""
    model_id: str
    cost_score: float      # 0-1 (1 = cheapest)
    speed_score: float     # 0-1 (1 = fastest)
    quality_score: float   # 0-1 (1 = highest quality)
    estimated_cost: float  # Actual USD cost


@dataclass
class OptimizationResult:
    """Result of multi-objective optimization."""
    recommended_model: str
    strategy: str
    scores: Dict[str, float]
    is_pareto_optimal: bool
    alternatives: List[Dict[str, Any]]


# Model performance estimates (placeholder - would be learned from data in production)
MODEL_BENCHMARKS = {
    "google/gemini-2.0-flash-lite": {
        "base_latency_ms": 800,
        "quality_rating": 0.70,
        "tier": "ultra-cheap"
    },
    "google/gemini-2.5-flash": {
        "base_latency_ms": 1500,
        "quality_rating": 0.85,
        "tier": "cheap"
    },
    "alibaba-sg/qwen-turbo": {
        "base_latency_ms": 1000,
        "quality_rating": 0.72,
        "tier": "ultra-cheap"
    },
    "alibaba-sg/qwen-coder": {
        "base_latency_ms": 1800,
        "quality_rating": 0.88,
        "tier": "cheap"
    },
    "alibaba-sg/qwen3.5-122b-a10b": {
        "base_latency_ms": 2200,
        "quality_rating": 0.92,
        "tier": "medium"
    },
    "anthropic/claude-sonnet-4-6": {
        "base_latency_ms": 3500,
        "quality_rating": 0.96,
        "tier": "expert"
    },
    "anthropic/claude-opus-4-6": {
        "base_latency_ms": 5000,
        "quality_rating": 0.98,
        "tier": "nuclear"
    }
}

# Strategy weight configurations
STRATEGY_WEIGHTS = {
    Strategy.COST_FIRST: {"cost": 0.7, "speed": 0.1, "quality": 0.2},
    Strategy.SPEED_FIRST: {"cost": 0.1, "speed": 0.7, "quality": 0.2},
    Strategy.QUALITY_FIRST: {"cost": 0.2, "speed": 0.2, "quality": 0.6},
    Strategy.BALANCED: {"cost": 0.33, "speed": 0.33, "quality": 0.34}
}


def load_model_pricing() -> Dict[str, Any]:
    """Load model pricing configuration."""
    try:
        with open(PRICING_PATH) as f:
            return json.load(f)
    except FileNotFoundError:
        return {"models": {}}


def calculate_cost_score(model_id: str) -> float:
    """
    Calculate cost score (higher = cheaper/better value).

    Args:
        model_id: Full model identifier

    Returns:
        Score from 0-1 (1 = cheapest)
    """
    pricing = load_model_pricing()
    models = pricing.get("models", {})

    model_config = models.get(model_id, {})
    input_cost = model_config.get("input_cost_per_million_tokens", 5.0)
    output_cost = model_config.get("output_cost_per_million_tokens", 15.0)

    # Average cost per token (simplified)
    avg_cost = (input_cost + output_cost) / 2

    # Normalize: $0.10 = score 1.0, $15.00 = score 0.0
    max_cost = 30.0  # Most expensive model threshold
    score = max(0.0, min(1.0, 1.0 - (avg_cost / max_cost)))

    return round(score, 2)


def calculate_speed_score(model_id: str) -> float:
    """
    Calculate speed score (higher = faster/better).

    Args:
        model_id: Full model identifier

    Returns:
        Score from 0-1 (1 = fastest)
    """
    benchmark = MODEL_BENCHMARKS.get(model_id, {"base_latency_ms": 3000})
    latency = benchmark.get("base_latency_ms", 3000)

    # Normalize: 500ms = score 1.0, 5000ms = score 0.0
    max_latency = 5000
    score = max(0.0, min(1.0, 1.0 - ((latency - 500) / (max_latency - 500))))

    return round(score, 2)


def calculate_quality_score(model_id: str) -> float:
    """
    Calculate quality score based on historical data or benchmarks.

    Args:
        model_id: Full model identifier

    Returns:
        Score from 0-1 (1 = highest quality)
    """
    benchmark = MODEL_BENCHMARKS.get(model_id, {"quality_rating": 0.80})
    return benchmark.get("quality_rating", 0.80)


def get_model_profile(model_id: str) -> ModelProfile:
    """
    Get complete profile for a model.

    Args:
        model_id: Full model identifier

    Returns:
        ModelProfile with all objective scores
    """
    pricing = load_model_pricing()
    model_config = pricing.get("models", {}).get(model_id, {})

    # Estimate cost for medium query
    input_cost = model_config.get("input_cost_per_million_tokens", 1.0)
    output_cost = model_config.get("output_cost_per_million_tokens", 2.0)
    estimated_cost = (500 * input_cost + 1000 * output_cost) / 1_000_000

    return ModelProfile(
        model_id=model_id,
        cost_score=calculate_cost_score(model_id),
        speed_score=calculate_speed_score(model_id),
        quality_score=calculate_quality_score(model_id),
        estimated_cost=estimated_cost
    )


def find_optimal_model(
    topic: str,
    complexity: str = "medium",
    strategy: Strategy = Strategy.BALANCED,
    use_pareto: bool = False
) -> OptimizationResult:
    """
    Find optimal model based on weighted multi-objective scoring.

    Args:
        topic: Query topic (for future learning integration)
        complexity: Query complexity level
        strategy: Optimization strategy to use
        use_pareto: Also return Pareto frontier analysis

    Returns:
        OptimizationResult with recommendation and alternatives
    """
    # Load available models
    pricing = load_model_pricing()
    models = list(pricing.get("models", {}).keys())

    # Get weights for strategy
    weights = STRATEGY_WEIGHTS.get(strategy, STRATEGY_WEIGHTS[Strategy.BALANCED])

    # Profile all models
    profiles = [get_model_profile(m) for m in models if m in MODEL_BENCHMARKS]

    # Calculate weighted scores
    scored_models = []
    for p in profiles:
        weighted_score = (
            weights["cost"] * p.cost_score +
            weights["speed"] * p.speed_score +
            weights["quality"] * p.quality_score
        )
        scored_models.append({
            "profile": p,
            "weighted_score": weighted_score,
            "breakdown": {
                "cost_contribution": weights["cost"] * p.cost_score,
                "speed_contribution": weights["speed"] * p.speed_score,
                "quality_contribution": weights["quality"] * p.quality_score
            }
        })

    # Sort by weighted score
    scored_models.sort(key=lambda x: x["weighted_score"], reverse=True)

    # Best recommendation
    best = scored_models[0]
    recommended = best["profile"].model_id

    # Calculate Pareto frontier if requested
    pareto_frontier = _find_pareto_frontier(profiles) if use_pareto else []

    # Prepare alternatives
    alternatives = [
        {
            "model_id": m["profile"].model_id,
            "model_name": m["profile"].model_id.split('/')[-1],
            "weighted_score": m["weighted_score"],
            "cost_score": m["profile"].cost_score,
            "speed_score": m["profile"].speed_score,
            "quality_score": m["profile"].quality_score,
            "estimated_cost": m["profile"].estimated_cost,
            "rank": i + 1
        }
        for i, m in enumerate(scored_models[1:4])  # Top 4 excluding best
    ]

    return OptimizationResult(
        recommended_model=recommended,
        strategy=strategy.value,
        scores={
            "weighted_score": best["weighted_score"],
            **best["breakdown"]
        },
        is_pareto_optimal=recommended in pareto_frontier,
        alternatives=alternatives
    )


def _find_pareto_frontier(profiles: List[ModelProfile]) -> List[str]:
    """
    Find Pareto-optimal models (no other model dominates in all objectives).

    A model is Pareto-optimal if no other model is strictly better in ALL objectives.
    """
    frontier = []

    for candidate in profiles:
        dominated = False

        for other in profiles:
            if other.model_id == candidate.model_id:
                continue

            # Check if other dominates candidate
            if (other.cost_score >= candidate.cost_score and
                other.speed_score >= candidate.speed_score and
                other.quality_score > candidate.quality_score):
                dominated = True
                break
            elif (other.cost_score >= candidate.cost_score and
                  other.speed_score > candidate.speed_score and
                  other.quality_score >= candidate.quality_score):
                dominated = True
                break
            elif (other.cost_score > candidate.cost_score and
                  other.speed_score >= candidate.speed_score and
                  other.quality_score >= candidate.quality_score):
                dominated = True
                break

        if not dominated:
            frontier.append(candidate.model_id)

    return frontier


def compare_strategies(topic: str, complexity: str = "medium") -> Dict[str, OptimizationResult]:
    """
    Compare all strategies for a given query.

    Args:
        topic: Query topic
        complexity: Query complexity level

    Returns:
        Dictionary mapping strategy names to results
    """
    results = {}

    for strategy in Strategy:
        result = find_optimal_model(topic, complexity, strategy)
        results[strategy.value] = {
            "recommended_model": result.recommended_model,
            "model_name": result.recommended_model.split('/')[-1],
            "weighted_score": result.scores["weighted_score"],
            "est_cost": next(
                (m.profile.estimated_cost for m in [get_model_profile(result.recommended_model)]),
                0
            ),
            "scores_breakdown": result.scores
        }

    return results


def set_custom_weights(weights: Dict[str, float]) -> bool:
    """
    Set custom optimization weights.

    Args:
        weights: Dictionary with cost, speed, quality weights (should sum to 1.0)

    Returns:
        True if successful
    """
    try:
        if abs(sum(weights.values()) - 1.0) > 0.01:
            raise ValueError("Weights must sum to 1.0")

        config = {}
        config.setdefault("custom_strategy", {})
        config["custom_strategy"]["weights"] = weights

        with open(CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=2)

        return True
    except Exception as e:
        print(f"Error setting custom weights: {e}")
        return False


def predict_performance(model_id: str, complexity: str = "medium") -> Dict[str, Any]:
    """
    Predict expected performance metrics for a model.

    Args:
        model_id: Model to analyze
        complexity: Query complexity

    Returns:
        Dictionary with predicted metrics
    """
    profile = get_model_profile(model_id)
    benchmark = MODEL_BENCHMARKS.get(model_id, {})

    # Adjust latency by complexity
    latency_multiplier = {"simple": 0.6, "medium": 1.0, "complex": 1.5, "architectural": 2.0}
    multiplier = latency_multiplier.get(complexity, 1.0)
    predicted_latency = int(benchmark.get("base_latency_ms", 3000) * multiplier)

    return {
        "model_id": model_id,
        "estimated_cost": profile.estimated_cost,
        "predicted_latency_ms": predicted_latency,
        "expected_quality": profile.quality_score,
        "cost_score": profile.cost_score,
        "speed_score": profile.speed_score,
        "quality_score": profile.quality_score
    }


if __name__ == "__main__":
    # Simple test when run directly
    print("=" * 60)
    print("MULTI-OBJECTIVE OPTIMIZATION - Self Test")
    print("=" * 60)

    print("\n📊 Testing optimization strategies:\n")

    # Test each strategy
    strategies = [Strategy.COST_FIRST, Strategy.SPEED_FIRST, Strategy.QUALITY_FIRST, Strategy.BALANCED]

    for strategy in strategies:
        print(f"Strategy: {strategy.value.upper()}")
        result = find_optimal_model("lambda-development", "medium", strategy, use_pareto=True)

        print(f"  Recommended: {result.recommended_model.split('/')[-1]}")
        print(f"  Weighted score: {result.scores['weighted_score']:.3f}")
        print(f"  Cost contrib: {result.scores['cost_contribution']:.3f}")
        print(f"  Speed contrib: {result.scores['speed_contribution']:.3f}")
        print(f"  Quality contrib: {result.scores['quality_contribution']:.3f}")
        print(f"  Pareto optimal: {result.is_pareto_optimal}")

        if result.alternatives:
            print(f"  Alternatives:")
            for alt in result.alternatives[:2]:
                print(f"    - {alt['model_name']} (score: {alt['weighted_score']:.3f})")
        print()

    print("-" * 60)

    # Compare all strategies
    print("\nStrategy Comparison:\n")
    comparisons = compare_strategies("lambda-development", "medium")

    print(f"{'Strategy':<20} {'Recommended':<25} {'Score':>10} {'Cost':>10}")
    print("-" * 65)

    for strat_name, data in comparisons.items():
        print(f"{strat_name:<20} {data['model_name']:<25} {data['weighted_score']:>10.3f} ${data['est_cost']:>8.4f}")

    print("\n" + "-" * 60)

    # Test prediction
    print("\nPerformance Prediction:\n")
    predictions = predict_performance("alibaba-sg/qwen3.5-122b-a10b", "complex")
    print(f"Model: qwen3.5-122b-a10b")
    print(f"  Est. cost: ${predictions['estimated_cost']:.6f}")
    print(f"  Latency: {predictions['predicted_latency_ms']}ms")
    print(f"  Quality: {predictions['expected_quality']:.0%}")
    print(f"  Speed score: {predictions['speed_score']:.2f}")

    print("\n" + "=" * 60)
    print("Test complete!")
