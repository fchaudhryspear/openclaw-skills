# 🚀 Quick Start Guide - Model Orchestrator v2.0

**Time Required:** 5-10 minutes  
**Prerequisites:** Python 3.9+, Node.js 18+ (for Antfarm later)

---

## Step 1: Extract Bundle

```bash
cd /opt/nexdev  # or your preferred location
unzip nexdev-mo-deployment.zip
cd nexdev-mo-deployment
```

---

## Step 2: Initialize Database

```bash
python3 source/init_db.py
```

Expected output:
```
============================================================
📦 MODEL ORCHESTRATOR - DATABASE INITIALIZATION
============================================================

✅ Directory ready: ~/memory
✅ Database created at ~/memory/project_graph.db
   Tables: projects, tasks, performance_logs, daily_costs, session_state

✅ Created model_pricing.json
✅ Created routing_topics.json
✅ Created CLI wrapper: ~/.openclaw/bin/mo-stats

🎉 All checks passed! System is ready.
```

---

## Step 3: Configure API Keys

Add these to your `~/.zshrc` or `.bashrc`:

```bash
export GEMINI_API_KEY="your-gemini-api-key-here"
export ANTHROPIC_API_KEY="your-anthropic-key-here"
export QWEN_API_KEY="your-qwen-key-here"  # Optional
export XAI_API_KEY="your-xai-key-here"     # Optional
```

Then reload shell:
```bash
source ~/.zshrc
```

---

## Step 4: Run Tests

```bash
python3 source/test_all_modules.py
```

You should see all modules pass with ✅ marks.

---

## Step 5: Test Routing

```bash
python3 source/topic_extractor.py
```

Expected output shows topics being detected from sample queries.

---

## Step 6: View Dashboard

```bash
mo-stats --help
mo-stats          # Overview of all topics
mo-stats --costs  # Cost breakdown
```

---

## Next Steps

### For Production Deployment

1. **Read full implementation guide**: `docs/NEXDEV_PHASE1_IMPLEMENTATION.md`
2. **Integrate with OpenClaw**: Add routing hooks to AGENTS.md
3. **Deploy Antfarm workflows**: Install bug-fix + feature-dev templates
4. **Set up monitoring**: Configure daily budget alerts and reports

### For Testing/Evaluation

Just start using the modules directly:

```python
from source.topic_extractor import extract_topic
from source.performance_logger import log_query_result

query = "Fix Lambda CORS error"
topics = extract_topic(query)
print(f"Detected topics: {topics}")
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Module not found | `export PYTHONPATH="$HOME/memory:$PYTHONPATH"` |
| Database locked | Check for other processes using DB, kill them |
| API key errors | Verify keys in environment: `echo $GEMINI_API_KEY` |
| mo-stats not found | Check `~/.openclaw/bin/` is in PATH |

---

## Support

- Full docs: `docs/NEXDEV_CODING_STACK_DESIGN.md`
- Implementation: `docs/NEXDEV_PHASE1_IMPLEMENTATION.md`
- Questions: Contact Fas/Optimus for consultation

---

*Happy routing! ⚡*
