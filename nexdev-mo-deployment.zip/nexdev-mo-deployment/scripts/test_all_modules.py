#!/usr/bin/env python3
"""
Comprehensive Test Suite for Model Orchestrator v2.0

Tests all 11 modules across Phases 1-5.
Run after installation to verify everything works correctly.
"""

import sys
from pathlib import Path

# Add source directory to path
SOURCE_DIR = Path(__file__).parent.parent / "source"
sys.path.insert(0, str(SOURCE_DIR))


def print_section(title):
    """Print formatted section header."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def print_test(name, status, details=""):
    """Print individual test result."""
    symbol = "✅" if status else "❌"
    print(f"  {symbol} {name}")
    if details:
        print(f"     {details}")


def run_phase1_tests():
    """Test Phase 1: Core Learning Engine."""
    print_section("PHASE 1: CORE LEARNING ENGINE")
    
    results = []
    
    try:
        from topic_extractor import extract_topic, debug_topic_extraction
        
        query = "Fix Lambda timeout causing 504 errors"
        result = debug_topic_extraction(query)
        
        has_matches = len(result['matches']) > 0
        correct_topic = any('lambda' in m['topic'] for m in result['matches'])
        
        print_test(
            "Topic Extractor",
            has_matches and correct_topic,
            f"Detected {len(result['matches'])} topics including lambda-development"
        )
        results.append(has_matches and correct_topic)
    except Exception as e:
        print_test("Topic Extractor", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        from performance_logger import log_query_result, get_best_model_for_topic, init_database
        
        init_database()
        test_result = log_query_result(
            "test-topic", "test-model", True, 100, 200, 0.001, 0.9
        )
        
        logged_successfully = test_result.get('status') == 'logged'
        print_test(
            "Performance Logger",
            logged_successfully,
            f"Logged test query with ID {test_result.get('record_id', 'N/A')}"
        )
        results.append(logged_successfully)
    except Exception as e:
        print_test("Performance Logger", False, f"Error: {str(e)}")
        results.append(False)
    
    return all(results)


def run_phase2_tests():
    """Test Phase 2: Intelligence Features."""
    print_section("PHASE 2: INTELLIGENCE FEATURES")
    
    results = []
    
    try:
        from confidence_assessor import assess_confidence, self_score_query
        
        strong_response = "Here is the solution that will definitely work!"
        weak_response = "You might want to try checking the documentation..."
        
        strong_conf = assess_confidence(strong_response).score
        weak_conf = assess_confidence(weak_response).score
        
        scores_correct = strong_conf > weak_conf
        print_test(
            "Confidence Assessor",
            scores_correct,
            f"Strong: {strong_conf:.2f}, Weak: {weak_conf:.2f}"
        )
        results.append(scores_correct)
    except Exception as e:
        print_test("Confidence Assessor", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        from cost_efficiency import calculate_cost, get_efficiency_formula
        
        # Test cost calculation
        cost = calculate_cost("google/gemini-2.0-flash-lite", 500, 1000)
        cost_valid = 0 < cost < 0.01
        
        # Test efficiency formula
        efficiency = get_efficiency_formula(0.9, 0.001)
        efficiency_positive = efficiency > 0
        
        print_test(
            "Cost Efficiency Analyzer",
            cost_valid and efficiency_positive,
            f"Cost: ${cost:.6f}, Efficiency: {efficiency:.1f}"
        )
        results.append(cost_valid and efficiency_positive)
    except Exception as e:
        print_test("Cost Efficiency Analyzer", False, f"Error: {str(e)}")
        results.append(False)
    
    return all(results)


def run_phase3_tests():
    """Test Phase 3: Monitoring Tools."""
    print_section("PHASE 3: MONITORING TOOLS")
    
    results = []
    
    try:
        from mo_dashboard import show_all_topics, ensure_database
        
        db_ok = ensure_database()
        print_test(
            "Database Connection",
            db_ok,
            "SQLite database accessible" if db_ok else "Database not found"
        )
        results.append(db_ok)
    except Exception as e:
        print_test("Database Connection", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        # Import and check dashboard functions exist
        from mo_dashboard import (
            show_all_topics,
            show_topic_details,
            show_costs,
            prune_stale_topics,
            reset_database
        )
        
        all_functions_exist = True
        print_test(
            "Dashboard CLI Functions",
            all_functions_exist,
            "All 5 main functions available"
        )
        results.append(all_functions_exist)
    except Exception as e:
        print_test("Dashboard CLI Functions", False, f"Error: {str(e)}")
        results.append(False)
    
    return all(results)


def run_phase4_tests():
    """Test Phase 4: Production Features."""
    print_section("PHASE 4: PRODUCTION FEATURES")
    
    results = []
    
    try:
        from topic_classifier import auto_classify_topic, should_use_llm_classifier
        
        query = "Design scalable microservice architecture"
        result = auto_classify_topic(query)
        
        classified = result.get('topic') is not None and result.get('method') is not None
        print_test(
            "LLM Topic Classifier",
            classified,
            f"Classified as '{result.get('topic')}' using {result.get('method')}"
        )
        results.append(classified)
    except Exception as e:
        print_test("LLM Topic Classifier", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        from session_aware_router import get_session_summary, start_session
        
        summary = get_session_summary()
        has_state = summary.get('current_topic') is not None
        
        print_test(
            "Session Aware Router",
            has_state,
            f"Current topic: {summary.get('current_topic')}, "
            f"Queries: {summary.get('total_queries', 0)}"
        )
        results.append(has_state)
    except Exception as e:
        print_test("Session Aware Router", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        from cost_monitor import calculate_query_cost, check_budget, get_daily_cost_report
        
        cost = calculate_query_cost("alibaba-sg/qwen3.5-122b-a10b", "medium")
        budget_check = check_budget("alibaba-sg/qwen3.5-122b-a10b", "medium")
        report = get_daily_cost_report()
        
        all_working = (
            isinstance(cost, float) and 
            hasattr(budget_check, 'within_budget') or 
            isinstance(budget_check, dict) and
            'daily_summary' in report
        )
        
        print_test(
            "Cost Monitor",
            all_working,
            f"Estimate: ${cost:.6f}, Daily: ${report['daily_summary']['total_spent']:.4f}"
        )
        results.append(all_working)
    except Exception as e:
        print_test("Cost Monitor", False, f"Error: {str(e)}")
        results.append(False)
    
    return all(results)


def run_phase5_tests():
    """Test Phase 5: Advanced Optimization."""
    print_section("PHASE 5: ADVANCED OPTIMIZATION")
    
    results = []
    
    try:
        from rl_feedback import record_feedback, get_model_preference, get_feedback_stats
        
        feedback_id = f"test-{hash(str(len(results)))}"
        result = record_feedback(
            feedback_id, "test-topic", "test-model", 5, "Test comment"
        )
        
        recorded = result.get('status') == 'recorded'
        print_test(
            "RL Feedback System",
            recorded,
            f"Recorded rating {result.get('rating', 'N/A')}/5"
        )
        results.append(recorded)
    except Exception as e:
        print_test("RL Feedback System", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        from multi_objective import find_optimal_model, Strategy
        
        result = find_optimal_model("test-topic", "medium", Strategy.BALANCED)
        
        has_recommendation = (
            hasattr(result, 'recommended_model') and
            result.recommended_model is not None
        )
        
        print_test(
            "Multi-Objective Optimization",
            has_recommendation,
            f"Recommended: {result.recommended_model.split('/')[-1]} "
            f"(score: {result.scores['weighted_score']:.3f})"
        )
        results.append(has_recommendation)
    except Exception as e:
        print_test("Multi-Objective Optimization", False, f"Error: {str(e)}")
        results.append(False)
    
    try:
        from semantic_topics import classify_with_embedding, _create_lightweight_embedding
        
        query = "Fix AWS Lambda timeout issues"
        matches = classify_with_embedding(query)
        
        # Create embedding
        embedding = _create_lightweight_embedding(query)
        embedding_dim = len(embedding)
        
        working = len(matches) > 0 and embedding_dim > 0
        print_test(
            "Semantic Topic Discovery",
            working,
            f"Embedding: {embedding_dim} dims, Matches: {len(matches)}"
        )
        results.append(working)
    except Exception as e:
        print_test("Semantic Topic Discovery", False, f"Error: {str(e)}")
        results.append(False)
    
    return all(results)


def generate_summary(total_tests, passed_tests):
    """Print final summary."""
    print_section("TEST SUMMARY")
    
    percentage = (passed_tests / total_tests * 100) if total_tests > 0 else 0
    
    print(f"\n  Total Tests:  {total_tests}")
    print(f"  Passed:       {passed_tests} ✅")
    print(f"  Failed:       {total_tests - passed_tests} ❌")
    print(f"  Success Rate: {percentage:.1f}%")
    
    print("\n" + "=" * 60)
    
    if percentage == 100:
        print("  🎉 ALL TESTS PASSED! System ready for production.")
    elif percentage >= 80:
        print("  ⚠️  Most tests passed. Review failures before deploying.")
    else:
        print("  ❌ Multiple failures. Check configuration and retry.")
    
    print("=" * 60)
    
    return percentage >= 80


def main():
    """Run all tests and generate summary."""
    print("\n" + "=" * 60)
    print("  🧪 MODEL ORCHESTRATOR V2.0 - COMPREHENSIVE TEST SUITE")
    print("=" * 60)
    
    all_results = []
    
    # Run phase tests
    all_results.extend(run_phase1_tests())
    all_results.extend(run_phase2_tests())
    all_results.extend(run_phase3_tests())
    all_results.extend(run_phase4_tests())
    all_results.extend(run_phase5_tests())
    
    # Count passes/fails
    passed = sum(all_results)
    total = len(all_results)
    
    # Generate summary
    success = generate_summary(total, passed)
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
